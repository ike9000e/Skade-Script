
#ifndef _SCIPP_AXB_P_H_
#define _SCIPP_AXB_P_H_
#include "scipp_tryparser.h"

class ScpTryProgramParse;

/*
	Expression -> AssignmentExpression->...-> BitwiseANDExpression
	->...-> EqualityExpression->...-> AdditiveExpression
	-> MultiplicativeExpression-> UnaryExpression-> PostfixExpression
	-> LeftHandSideExpression->...
	-> CallExpression -> MemberExpression -> PrimaryExpression

	CallExpression

	MultiplicativeExpression : See section 11.5
		UnaryExpression
		MultiplicativeExpression * UnaryExpression
		MultiplicativeExpression / UnaryExpression
		MultiplicativeExpression % UnaryExpression

	Note: in simplified parsing, UnaryExpression is reduced to a PrimaryExpression,
	_     whitch in turn, in even more simplier parsing, can be
	_     just identifier and literals.
*/
class ScpTryAxBExpr : public ScpITryParser {
public:
	;                       ScpTryAxBExpr( const char* op1="*", const char* op2=0, const char* op3=0, const char* op4=0 );
	virtual                 ~ScpTryAxBExpr() {}
	virtual bool            tryy( const ScpParse& inp );
private:
	virtual ScpITryParser*  getLeftAxBExprParser();
private:
	std::vector<std::string> Ops;
};
/*
	AdditiveExpression : See section 11.6
		MultiplicativeExpression
		AdditiveExpression + MultiplicativeExpression
		AdditiveExpression - MultiplicativeExpression
*/
class ScpTryAdditiveExpr : public ScpTryAxBExpr {
public:
	ScpTryAdditiveExpr();
private:
	virtual ScpITryParser* getLeftAxBExprParser();
};
/*
	PrimaryExpression : See section 11.1
		this
		Identifier
		Literal
		ArrayLiteral
		ObjectLiteral
		( Expression )
*/
class ScpTryPrimaryExpr : public ScpITryParser {
public:
	virtual ~ScpTryPrimaryExpr() {}
	virtual bool tryy( const ScpParse& inp );
};
class ScpTryIdentifierExpr : public ScpITryParser
{
public:
	virtual bool tryy( const ScpParse& inp );
};
/*
	AssignmentExpression : See section 11.13
		ConditionalExpression
		LeftHandSideExpression AssignmentOperator AssignmentExpression
*/
class ScpTryAsgmntExpr : public ScpTryAxBExpr
{
public:
	ScpTryAsgmntExpr();
	virtual ScpITryParser* getLeftAxBExprParser();
};
/*
	Grouping expression using parentheses.
	The '( Expression )' expression.

	11.1.6 The Grouping Operator
	The production PrimaryExpression : ( Expression ) is evaluated as follows:
		1. Evaluate Expression. This may be of type Reference.
		2. Return Result(1).

	ref: CTryGroupingOpExpr, ETK_PN_PARENTHESES_OPEN, jsc_GlobTryTheExpr
*/
class ScpTryGroupingExpr : public ScpITryParser {
public:
	ScpTryGroupingExpr( const ScpTryProgramParse* program2 );
	virtual bool tryy( const ScpParse& inp );
	virtual ScpITryParser* getInnerExprParser();
private:
	ScpTCITR LastTokenAt;
};

/*
	CallExpression :
		MemberExpression Arguments
		CallExpression Arguments
		CallExpression [ Expression ]
		CallExpression . Identifier

	Arguments :
		( )
		( ArgumentList )

	ArgumentList :
		AssignmentExpression
		ArgumentList , AssignmentExpression
*/
class ScpTryCallExpr : public ScpITryParser {
public:
	ScpTryCallExpr() {}
	virtual bool tryy( const ScpParse& inp );
};
class ScpTryArgumentsExpr : public ScpITryParser {
public:
	ScpTryArgumentsExpr() {}
	virtual bool tryy( const ScpParse& inp );
};

/**
	Str literal as an expression.
	Inherriting from expr, rather than own class, as it seems easy
	to implement. Evaluating would parse str-piece for escape character sequences
	and return escaped string. Other functionality is possible to add here,
	like shell-style variables inside dbl-quoted strings or use of raw strings.
*/
class ScpTryStringLiteral : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};

/*
	list of elements:
		PropertyName : AssignmentExpression
*/
class ScpTryObjectLiteral : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};
/*
	PropertyName :
		IdentifierName
		StringLiteral
		NumericLiteral
*/
class ScpTryPropertyName : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};


class ScpTryVarStmt : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};

#endif // _SCIPP_AXB_P_H_
