#include "scipp_value.h"
#include <stdio.h>
#include <assert.h>
#include <cstdlib>    //strtoll(), strtod()
#include "scipp_tryparser.h"
#include "../inc/scipp/scipp_script.h"
#include "scipp_expr.h"

static const bool bCountStaticVal = 0;
static int        nCountStaticVal = 0;
ScpValue::ScpValue( const ScpToken* tknn )
	: Token2( !tknn ? new ScpToken : new ScpToken( *tknn ) )
	, RefCnt(1)
{
	if(bCountStaticVal)
		printf("ScpValue() %d\n", ++nCountStaticVal );
}
ScpValue::~ScpValue()
{
	if(bCountStaticVal)
		printf("~ScpValue() %d\n", --nCountStaticVal );
	if( Token2 ){
		delete Token2;
		Token2 = 0;
	}
}
int ScpValue::getValueType()const
{
	return SCP_E2_Unknown;
}
/// For internal use, should be never used by user code.
void ScpValue::grabVal()
{
	++RefCnt;
}
/// For internal use, should be never used by user code.
bool ScpValue::dropVal()
{
	--RefCnt;
	assert( RefCnt >= 0 );
	if( !RefCnt ){
		delete this;
		return 1;
	}
	return 0;
}

/**
    Gets called when a multiplicative expression
    is being evaluated on the variable in the script.

    Multiplicative expression uses the '*' operator.
    This member function is called on a variable that is on the left side of
    the operator.

    Implementation must create new variable (using the *new* keyword)
    and return it via \ref ScpSpeOper::result2 ".result2"
    member of the input ScpSpeOper structure, at the same time,
	returning *true* (success) as the actual return value.

    Created and returned object should be of the same class as the object
    that this call is performed on. Using different class
    (while still derived from ScpHostValue or ScpValue) can peoduce
    undefined behaviour.
*/
bool ScpValue::evalOperatorMul( const ScpSpeOper& inp )const
{
	//Token2->tkn; ScpSp(0,0)
	genericOperError(inp,"*");
	return 0;
}
/// Operator add.
/// See ScpValue::evalOperatorMul().
bool ScpValue::evalOperatorAdd( const ScpSpeOper& inp )const
{
	genericOperError(inp,"+");
	return 0;
}
/// Operator sub.
/// See ScpValue::evalOperatorMul().
bool ScpValue::evalOperatorSub( const ScpSpeOper& inp )const
{
	genericOperError(inp,"-");
	return 0;
}
/// Operator div.
/// See ScpValue::evalOperatorMul().
bool ScpValue::evalOperatorDiv( const ScpSpeOper& inp )const
{
	genericOperError(inp,"/");
	return 0;
}
/// Operator percent.
/// See ScpValue::evalOperatorMul().
bool ScpValue::evalOperatorPercent( const ScpSpeOper& inp )const
{
	genericOperError(inp,"%");
	return 0;
}


/**
	Gets called when an assignment expression
	is being evaluated on the variable in the script.

	Assignment expression uses the '=' operator.
	This member function is called on a variable that is on the left side of
	the assignment operator.

	Use \ref ScpSpeOper::otherr ".otherr" member of the input
	ScpSpeOper structure to access the value that is being assigned,
	the right hand side value.

	Unlike other eval\* member functions, this function is non-const, thus
	allows internal members of the variable to be modified, i.e. to reflect
	the result of the assignment.

	Default implementation returns *false* thus does not allow any assignment
	and triggers error on the evaluation. Return value *true* indicatess success.
*/
bool ScpValue::evalOperatorAssign( const ScpSpeOper& inp )
{
	//std::string str = stdToString();
	//printf("str:[%s]\n",str.c_str());
	genericOperError(inp,"=");
	return 0;
}
void ScpValue::genericOperError( const ScpSpeOper& inp, const char* szOper )const
{
	assert(Token2);
	inp.sev.errClear2( ScpErr( Token2->tkn, SCP_EE_OperatorNoImpl,
		(*ScpStr(
			"Operator '%a' not implemented for this value.").a(szOper)).c_str() ) );
}

/**
	Gets called when a function call expression is being evaluated on the
	variable in the script.

	In scripts, call expression is simply a variable name
	followed by an arguments enclosed in the parentheses.
	While parentheses are mandatory, there can be zero or more number of actual
	arguments that gets passed.

	Default implementation of this virtual function doesn't allow the call
	expression to be performed and triggers the evaluation error via the return *false*.
	Continue reading for info on how to implement this member function in
	the derived class.

	To access actual arguments, use following members of
	the input ScpSpeCall structure:
	\ref ScpSpeCall::argc2 "argc2" and \ref ScpSpeCall::argv2 "argv2".
	Each passed argument is of type const pointer to ScpValue.
	ScpValue is a base class for all variables, built-ins (like string) or
	user defined (aka. host objects).

	Converting to two basic types are always provided: *std::string* and *double*.
	Converting to each is as easy as calling
	ScpValue::stdToString() and ScpValue::stdToDouble() on the actual input arguments.
	There is no need to obtain value type in advance as described below.
	Internally, numbers will be always automatically converted to strings and
	strings to numbers.

	To obtain more info on each argument, following routines can be used:

	- Member functions: ScpValue::stdToString() and ScpValue::stdToDouble(),
	  both convert to C built-in types and, in turn, are
	  implemented for all Script built-in types.
	- Call to member function \ref ScpValue::getValueType() ".getValueType()"
	  returns internal type of the variable.
	- Dynamic cast (*dynamic_cast* keyword) can be used to check if it is of
	  some expected derived type, for example, user derived class that
	  used ScpHostValue as it's base.

	In user code (C++), success must be indicated by return value *true*.

	See description of the ScpSpeCall::result2 member of the ScpSpeCall structure
	about how to create and return the *return* value.
*/
bool ScpValue::evalFunctionCall( const ScpSpeCall& inp )
{
	assert(Token2);
	inp.sev.errClear2( ScpErr( Token2->tkn, SCP_EE_OperatorNoImpl,
		"Function call not implemented for this value." ) );
	return 0;
}
/// Used internally to print contents of the value for debug purposes.
std::string ScpValue::strPrint3()const
{
	return "ScpValue;";
}

const ScpValue* ScpValue::
getPropertyAt( int indexAt, std::string* strPropertyName )const
{
	return 0;
}
ScpDummyVal::ScpDummyVal( const ScpToken& tknn )
	: ScpValue( &tknn )
{
}

ScpValAutoPtr::ScpValAutoPtr( ScpValue* inp, bool bGrab_ )
	: Ptr(inp)
{
	if( bGrab_ && Ptr )
		Ptr->grabVal();
}
void ScpValAutoPtr::setPointer( ScpValue* inp, bool bGrab_ )
{
	//if( Ptr )
	//	Ptr->dropVal();
	Ptr = inp;
	if( bGrab_ && Ptr )
		Ptr->grabVal();
}

ScpValListVal::ScpValListVal( const ScpToken& tknn )
	: ScpValue( &tknn )
{
}
ScpValListVal::~ScpValListVal()
{
/*	std::vector<std::pair<ScpValue*,bool> >::iterator a;
	for( a = values2.begin(); a != values2.end(); ++a ){
		if( a->second ){
			//delete a->first;
			a->first->dropVal();
		}
	}//*/
	std::vector<SVal>::iterator a;
	for( a = Values2.begin(); a != Values2.end(); ++a ){
		if( a->bOwn ){
			a->value5->dropVal();
		}
	}
	Values2.clear();
}
void ScpValListVal::addVal( ScpValue* inp, bool bOwnAndDel, const char* szVarname )
{
//	values2.push_back( std::pair<ScpValue*,bool>( inp, bOwnAndDel ) );
	assert(inp);
	SVal sva;
	sva.value5 = inp;
	sva.bOwn   = bOwnAndDel;
	sva.name3  = ( szVarname ? szVarname : "" );
	Values2.push_back( sva );
}
int ScpValListVal::getValCount()const
{
	//return (int)values2.size();
	return (int)Values2.size();
}
ScpValue* ScpValListVal::getValAt( int idx, std::string* nameOut )
{
	//if( idx < (int)values2.size() )
	//	return values2[idx].first;
	if( idx < (int)Values2.size() ){
		if(nameOut)
			*nameOut = Values2[idx].name3;
		return Values2[idx].value5;
	}
	return 0;
}
const ScpValue* ScpValListVal::getValAt( int idx, std::string* nameOut )const
{
	ScpValListVal* thisp = (ScpValListVal*)this;
	return thisp->getValAt( idx, nameOut );
}
const ScpValue* ScpValListVal::findValByName( const char* name_ )const
{
	std::vector<SVal>::const_iterator a;
	for( a = Values2.begin(); a != Values2.end(); ++a ){
		if( a->name3 == name_ )
			return a->value5;
	}
	return 0;
}
int ScpHostValue::getValueType()const
{
	return SCP_E2_HostObject;
}//*/
/// Constructs string value.
/// \param szStr - should be already parsed and evaluated string with
/// _              all escape sequences resolved.
ScpStrVal::ScpStrVal( const ScpToken& tknn, const char* szStr, int len )
	: ScpValue( &tknn )
	, Str( szStr, len )
{
}
bool ScpStrVal::evalOperatorAdd( const ScpSpeOper& inp )const
{
	std::string str = Str + inp.otherr->stdToString();
	const ScpToken* tke = getTokenIfAny();
	assert(tke);
	inp.sev.out4.value2 = new ScpStrVal( *tke, str.c_str(), (int)str.size() );
	return 1;
}
bool ScpStrVal::evalOperatorAssign( const ScpSpeOper& inp )
{
	const ScpStrVal* rval = dynamic_cast<const ScpStrVal*>( inp.otherr );
	if( !rval ){
		//const ScpToken* tknn2 = inp.sev.out4.value2->getTokenIfAny();
		const ScpToken* tknn2 = getTokenIfAny();
		assert(tknn2);
		const ScpToken* tknn3 = inp.otherr->getTokenIfAny();
		assert(tknn3);
		inp.sev.errClear2( ScpErr( tknn3->tkn, SCP_EE_OperatorNoImpl,
			"String type can only be reassigned to another string."
			//(*ScpStr(
			//	"Variable '%a'. String type can only be reassigned to another string.")
			//	.a(tknn2->tkn2.c_str()))
			//	.c_str()
			) );
		return 0;
	}
	Str = inp.otherr->stdToString();
	//inp.sev.out4.value2 = this;
	return 1;
}
double ScpStrVal::stdToDouble()const
{
	// strtod() //atof()
	return strtod( Str.c_str(), 0 );
}
int ScpObjLiteralVal::getPropertyCount()const
{
	return getValCount();
}
const ScpValue* ScpObjLiteralVal::
getPropertyAt( int indexAt, std::string* strPropertyName )const
{
	const ScpValue* val = getValAt( indexAt, strPropertyName );
	return val;
}
const ScpValue* ScpObjLiteralVal::getPropertyByName( const char* szVarname )const
{
	return findValByName( szVarname );
}



