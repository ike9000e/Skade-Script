#ifndef _SCIPP_SCRIPT2_H_
#define _SCIPP_SCRIPT2_H_
#include "scipp_tryparser.h"
#include "../inc/scipp/scipp_script.h"

class ScpTryProgramParse; class ScpValue;

/**
	Main class in the scripting engine.
	Processing of scripts is done in two steps: parsing and evaluating.
	Once the object is initialized, methods parse2() and eval2() can be
	used to process the script, in the default way using these two steps.
	Additional parsing methods are provided so that, for example, both steps can be
	combined into one.

	All parsing methods return bolean value that indicates whenever
	operation succeded or failed.
	Method \ref showMeTheError2() (or alternate \ref showMeTheError3())
	can be used to retrieve textual information, such as: type of error,
	row and column number, or the whole line that the error occured at.
*/
class ScpScript2 : public ScpScript, public ScpScope {
	struct SIfs;
public:
	;                   ScpScript2( const std::string& script_ );
	;                   ScpScript2( const char* script_, int len, bool bCreateInternalCopy );
	virtual             ~ScpScript2();
	virtual bool        parseAndEval();
	virtual bool        parse2();
	virtual bool        parse3( int flags_, ScpErr* err );
	virtual bool        eval2();
	virtual bool        eval3( int flags_, ScpErr* err );
	virtual void        showMeTheError2( int flags_ )const;
	virtual std::string showMeTheError3( int flags_ )const;
	//
	virtual void        addHostVariable( const char* varname, ScpValue* hostvar, bool bOwnAndDel );
	virtual void        clear2();
	virtual void        clear3( int flags_ );
	virtual void        setCondDef( const char* dname, bool val );
	virtual void        setOptions( int flags_ );
private:
	virtual bool     putScopeVariable( const ScpPutScopeVar& inp );
	virtual bool     getScopeVariable( const ScpGetScopeVar& inp );
	bool             tokenize2( ScpErr& err );
	bool             eval9( int flags4, ScpErr& err );
	bool             preprocessCondDefs( ScpErr& err );
	bool             scanUntilSequenceRecv( int dpth, size_t& ioNum, const ScpTITR& bgn, const ScpTITR& endd, int& mode3, SIfs& ifs2, ScpTITR& ended2, ScpErr& err, int mode4 );
	bool             applyCondDefs( ScpErr& err );
private:
	struct SIfdef{
		ScpTITR htg, wrd, cond2;
		int tpe4; // fe. EIDT_Ifdef.
		SIfdef( int tpe4_, ScpTITR htg_, ScpTITR wrd_ ) : htg(htg_), wrd(wrd_), tpe4(tpe4_) {}
	};
	struct SIfs{
		bool bInvalidated;
		std::vector<SIfdef> ifdefs2;
		SIfs() : bInvalidated(0) {}
	};
	enum{ EIDT_Ifdef, EIDT_Endif, EIDT_IfNdef, };
	enum{ EIDM_Ifs, EIDM_Els, };
	enum{ ESS_HaveLocalScrCopy = 0x1, };
	struct SVar{
		std::string    varname2;
		ScpValue*      value4;
		bool           bOwn3;
		SVar( const char* name_, ScpValue* val_=0, bool bOwn_=0 ) : varname2(name_), value4(val_), bOwn3(bOwn_) {}
		bool operator()( const SVar& otherr )const {return varname2 == otherr.varname2;}
	};
	std::vector<std::pair<std::string,std::string> > Defs; // cond-defs for pseudo preprocessor.
	int                           Flags2, Flags3; // fe. ESS_HaveLocalScrCopy.
	std::string                   ScriptCopy;
	std::pair<const char*,int>    ScriptCStr;
	ScpLsToken                    Tokens2; //std::list<ScpToken>
	ScpErr                        LastError;
	ScpTryProgramParse*           Prgrm;
	ScpLsToken                    myIfdef, myEndif, myIfNdef;
	std::vector<SIfs>             IfDefBlocks;
	std::vector<SVar>             VarStack;
};

#endif //_SCIPP_SCRIPT2_H_
