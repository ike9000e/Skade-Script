#include "scipp_script2.h"
#include <string.h>
#include <assert.h>
#include <algorithm>
#include <stdio.h>
#include "scipp_program.h"
#include "scipp_expr.h"
#include "scipp_value.h"

/// Constructs script object.
/// \param script_ - input script, internal copy of it is created.
ScpScript2::
ScpScript2( const std::string& script_ )
	: Flags2(0), Flags3(ESS_HaveLocalScrCopy), ScriptCopy(script_), ScriptCStr(0,0)
	, Prgrm(new ScpTryProgramParse)
{
	ScriptCStr = std::pair<const char*,int>( ScriptCopy.c_str(), (int)ScriptCopy.size() );
}
/// Constructs script object with an option to not to create local
/// copy of the input script.
/// \param script_ - Input script. if 'len' is set to -1, length of the c-string
///                  (aka. null-terminated string) is obtained via 'strlen()'.
/// \param len - Length of the input script in the characters. Set to -1 assumes
///              null-terminated.
/// \param bCreateInternalCopy - If set to true, local copy of the input script is created.
///                  Otherwise, caller must ensure data reamin valid through
///                  the entire life of the object.
///
/// \sa ScpCreateScript
ScpScript2::
ScpScript2( const char* script_, int len, bool bCreateInternalCopy )
	: Flags2(0), Flags3(0), ScriptCStr(0,0)
	, Prgrm(new ScpTryProgramParse)
{
	len = ( len != -1 ? len : strlen(script_) );
	if( !bCreateInternalCopy ){
		Flags3 &= ~ESS_HaveLocalScrCopy;
		ScriptCStr = std::pair<const char*,int>( script_, len );
	}else{
		Flags3 |= ESS_HaveLocalScrCopy;
		ScriptCopy.assign( script_, len );
		ScriptCStr = std::pair<const char*,int>( ScriptCopy.c_str(), (int)ScriptCopy.size() );
	}
}
ScpScript2::~ScpScript2()
{
	assert(Prgrm);
	delete Prgrm;
	{
		std::vector<SVar>::iterator a;
		for( a = VarStack.begin(); a != VarStack.end(); ++a ){
			if( a->bOwn3 ){
				a->value4->dropVal();
				a->value4 = 0;
			}
		}
		VarStack.clear();
	}
}
/**
	Creates script parser, the main object of the cripting engine.
	Returned pointer must be freed using the C++ *delete* operaator.

	Object create is with an option to not to create local
	copy of the input script.
	\param script_text - Input script. if 'len' is set to -1, length of the c-string
						 (aka. null-terminated string) is obtained via 'strlen()'.
	\param len - Length of the input script in the characters. Set to -1 assumes
				 null-terminated.
	\param bCreateInternalCopy - If set to true, local copy of the input script is created.
					 Otherwise, caller must ensure data reamin valid through
					 the entire life of the object.

	\sa ScpScript2
*/
ScpScript* ScpCreateScript( const char* script_text, int len, bool bCreateInternalCopy )
{
	return new ScpScript2( script_text, len, bCreateInternalCopy );
}
/// Constructs script object.
/// \param script_text - input script, internal copy of it is created.
ScpScript* ScpCreateScript( const std::string& script_text )
{
	return ScpCreateScript( script_text.c_str(), (int)script_text.size(), 1 );
}
/// Sets pseudo value for pseudo preprocessor.
/// This is done through the occurences of "#ifdef" or "#ifndef" conditional expressions.
/// Value name set here must be a single word.
/// operators such as logical or arithmetic cannot be part of the name.
/// Nesting is not supported, will trigger undefined behaviour. \n
/// WIP.
/// \todo Nesting in pseudo preprocessor.
/// \sa \ref pgPreproc
void ScpScript2::setCondDef( const char* dname, bool val )
{
	std::vector<std::pair<std::string,std::string> >::iterator a;
	if( (a = std::find_if( Defs.begin(), Defs.end(), ScpSp::PredStrStr(dname) )) != Defs.end() ){
		if(val){
			a->second = "1";
		}else{
			Defs.erase(a);
		}
	}else{
		if(val)
			Defs.push_back( std::pair<std::string,std::string>(dname,"1") );
	}
}
void ScpScript2::clear2()
{
	clear3( SCP_CF_ClearAll );
}
/// Clears stored results.
/// Clearing only selected results, rather than reinitializing the rntire
/// script object, may be usefull in saving some processing time.
/// \param flags3 - flags as an ORed list, fe. \ref SCP_CF_ClearStack.
void ScpScript2::clear3( int flags3 )
{
	LastError = ScpErr( ScpSp("",0), SCP_EE_Unknown );
	if( flags3 & SCP_CF_ClearCondDefs ){
		Defs.clear();
	}
	if( flags3 & SCP_CF_ClearParser ){
		Tokens2.clear();
		assert( Prgrm );
		delete Prgrm;
		Prgrm = new ScpTryProgramParse;
		IfDefBlocks.clear();
	}
	if( flags3 & SCP_CF_ClearStack ){
		;
	}
}

/// Tokenizes the script.
bool ScpScript2::tokenize2( ScpErr& err2 )
{
	Tokens2.clear();
	const char* sz2 = ScriptCStr.first, *sz3 = 0;
	int len2 = ScriptCStr.second;
	char chr;
	int tpe2 = 0;
	for( int i=0; i<len2; sz3=0, tpe2=0 ){
		chr = sz2[i];
		if(0){
		}else if( i+1 < len2 && !strncmp( &sz2[i], "//", 2 ) ){
			//printf("'//' at %d \n", i );
			static const char* szNl = "\n";
			const char* endd = &sz2[len2], *x;
			x = std::search( &sz2[i], endd, szNl, szNl+1 );
			// if not found, eat the remaining text, this is the last line, newline hasn't benn found.
			sz3 = ( x == endd ? &sz2[len2] : x + 1 );
			tpe2 = SCP_ET_Wh;
		}else if( i+1 < len2 && !strncmp( &sz2[i], "/*", 2 ) ){
			//printf("'/*' at %d \n", i );
			static const char* szAstSl = "*\x2F";  // 0x2F = '/'
			const char* endd = &sz2[len2], *x;
			if( (x=std::search( &sz2[i], endd, szAstSl, szAstSl+2 )) == endd ){
				err2 = ScpErr( ScpSp( &sz2[i], 2 ), SCP_EE_CommentNoClose, "Comment not closed.");
				return 0;
			}
			sz3 = x + 2;
			//printf("cl: [%s]\n", std::string(sz3,4).c_str() );
			tpe2 = SCP_ET_Wh;
		}else if( strchr( ScpSp::Ops, chr ) ){
			sz3 = &sz2[i] + 1;
			tpe2 = SCP_ET_Op;
		}else if( strchr( ScpSp::Whs, chr ) ){
			sz3 = ScpSp::strchrAdvance( &sz2[i], len2-i, ScpSp::Whs, 0 );
			tpe2 = SCP_ET_Wh;
		}else if( strchr( ScpSp::Wrd2, chr ) ){
			sz3 = ScpSp::strchrAdvance( &sz2[i], len2-i, ScpSp::Wrd2, ScpSp::Wrd3 );
			tpe2 = SCP_ET_Wrd;
		}else if( strchr( ScpSp::Qots, chr ) ){ //if string literal start.
			// advance by only scanning for string end position.
			int err = -1;
			if( !ScpSp::strLiteralEndqScan( &sz2[i], len2-i, &sz3, &err ) ){
				err2 = ScpErr( ScpSp( &sz2[i], 1 ), err );
				return 0;
			}
			tpe2 = SCP_ET_StrLiteral;
		}else{
			err2 = ScpErr( ScpSp( &sz2[i], 1 ), SCP_EE_UnkToken, "Unknown token encountered." );
			return 0;
		}
		assert( sz3 );
		int adv = sz3 - &sz2[i];
		ScpSp sp( &sz2[i], adv );
		Tokens2.push_back( ScpToken(sp,tpe2, ( tpe2 == SCP_ET_Wh ? 0:-1 ) ) );
		i += adv;
	}
	// remove unnecessary tokens, fe. whitespaces.
	ScpLsToken::iterator a;
	for( a = Tokens2.begin(); a != Tokens2.end(); ){
		if( a->tpe == SCP_ET_Wh ){
			a = Tokens2.erase(a);
		}else
			++a;
	}
	if( Flags2 & SCP_SF_ShowTokens ){
		ScpLsToken::iterator a;
		for( a = Tokens2.begin(); a != Tokens2.end(); ++a ){
			printf("%02d \x22%s\x22\n", a->tpe, a->tkn2.c_str() );
		}
	}
	return 1;
}
/// Parse and evaluates script in one call.
/// Suitable for small text scripts.
/// Equivalent of calling ScpScript2::eval3() with \ref SCP_AF_AutoParse flag set.
/// \sa \ref pgParseEval
bool ScpScript2::parseAndEval()
{
	if( parse2() )
		return eval2();
	return 0;
}
/**
	Parses the script.
	Script text must be set.
	Eval must not have been yet called.
	\sa \ref pgParseEval
*/
bool ScpScript2::parse2()
{
	return parse3( 0, 0 );
}
/// Parses the script with an option to return the error info.
/// \param flags3 - currntly not used, set to 0.
/// \sa \ref pgParseEval
/// \sa ScpScript2::parse2()
bool ScpScript2::parse3( int flags3, ScpErr* err )
{
	Prgrm->reinit2();
	ScpErr err3, &err2 = ( err ? *err : err3 );
	if( !tokenize2( err2 ) ){
		ScpSp::finalizeErr( err2, ScriptCStr.first, ScriptCStr.second );
		LastError = err2;
		return 0;
	}
	if( !(Flags2 & SCP_SF_DisablePreproc) ){
		// call pseudo preprocessor here, that modifies tokens list if needed.
		if( !preprocessCondDefs( err2 ) ){
			ScpSp::finalizeErr( err2, ScriptCStr.first, ScriptCStr.second );
			LastError = err2;
			return 0;
		}
	}
	ScpTCITR ended3;
	ScpParseOu ou2 = { 0, ended3, err2, };
	ScpParse prse( Tokens2.begin(), Tokens2.end(), ou2, Prgrm );
	if( !Prgrm->tryy( prse ) ){ // ScpTryProgramParse*
		ScpSp::finalizeErr( err2, ScriptCStr.first, ScriptCStr.second );
		LastError = err2;
		return 0;
	}
	if( Flags2 & SCP_SF_ShowExpressions ){
		Prgrm->setOriginalScript( ScriptCStr.first, ScriptCStr.second );
		printf("%s\n", Prgrm->strPrint2( ScpPrnt("") ).c_str() );
	}
	return 1;
}
/// Sets flags that are used durning script processing.
/// \param flags2 - flags as an ORed list, eg. \ref SCP_SF_ShowTokens.
void ScpScript2::setOptions( int flags2 )
{
	Flags2 = flags2;
}
/// Prints error to the console STDOUT.
/// \param flags_ - flags, eg. \ref SCP_EO_Short.
/// \sa ScpScript2::showMeTheError3()
void ScpScript2::showMeTheError2( int flags_ )const
{
	std::string z = showMeTheError3( flags_ );
	printf("%s", z.c_str() );
}

/// Returns error as std::string.
/// \param flags5 - flags, eg. \ref SCP_EO_Short.
std::string ScpScript2::showMeTheError3( int flags5 )const
{
	//std::string z;
	assert( LastError.iCol >= 0 );
	assert( LastError.iRow >= 0 );
	const ScpErr& err = LastError;

	struct SEnumMsg {
		int enumList[5];
		const char* message2;
	} altKnownMsgs[] = {
		{ {SCP_EE_Unknown,-1,}, "Unknown error.", },
		{ {SCP_EE_NewlineInStrLiteral,-1,}, "Newline character in string literal.", },
		{ {SCP_EE_NoSuchHostObject2,SCP_EE_NoSuchHostObject3,SCP_EE_NoSuchHostObject4,SCP_EE_NoSuchHostObject5,-1,},
					"No such host object.", },
		{ {SCP_EE_NoSuchHostOper,-1,}, "No such host operator.", },
		{ {SCP_EE_UnkErrOnUsrCall,-1,}, "Unknown error on user call.", },
		{ {SCP_EE_UsrCallNotImpl,-1,}, "User call not implemented.", },
		{ {-1,}, 0, },
	};
	std::string msgAlt;
	for( int i=0; altKnownMsgs[i].message2 && msgAlt.empty(); i++ ){
		for( int k=0; altKnownMsgs[i].enumList[k] != -1; k++ ){
			if( altKnownMsgs[i].enumList[k] == err.tpe3 ){
				msgAlt = altKnownMsgs[i].message2;
				break;
			}
		}
	}
	std::string lineAt = err.strErrorLine;
	// TODO: [x] strip leading whitespaces.
	//       [x] replace tabs with spaces.
	//       [ ] shift line left if too long.
	std::string strTorP;
	if( err.tpe3 >= SCP_EE_UserEvalNull ){
		strTorP = "Evaluating";
	}else if( err.tpe3 >= SCP_EE_EofOnParse ){
		strTorP = "Parsing";
	}else if( err.tpe3 >= SCP_EE_UnxpctdEndif ){
		strTorP = "Preprocessing";
	}else{ // assume >= SCP_EE_UnkToken.
		strTorP = "Tokenizing";
	}
	int iColModded = err.iCol;
	{
		lineAt = ScpSp::strReplace(lineAt,"\t"," ");
		// remove any leading whitespaces.
		std::string::iterator a;
		for( a = lineAt.begin(); a != lineAt.end() && *a == '\x20'; ++a, iColModded-- );
		lineAt.erase( lineAt.begin(), a );
		if( !(Flags2 & SCP_SF_NoErrLineRTrim) ){
			// max line length.
			size_t lenOri = lineAt.size();
			if( lenOri > 52 ){ // hardcoded, keeping 42-64 seems to be reasonable.
				lineAt.resize( 52, ' ' );
				lineAt += "...";
			}
		}
	}
	std::string z;
	msgAlt = ( !err.msg2.empty() ? err.msg2 : msgAlt );

	// RED='\033[0;31m' // 0x1B = 033
	// NC='\033[0m' # No Color
	// BBlack='\033[1;30m' # Black bold
	// ref: http://stackoverflow.com/questions/5947742/how-to-change-the-output-color-of-echo-in-linux
	z = *ScpStr(
			"ERROR: %a failed; line:%a, column:%a, enum:%a."  "%a\n"
			"%a%a"
			"       [%a]%a\n"
			"        %a\n")
			.a( strTorP.c_str() )
			.a( err.iRow+1 )
			.a( err.iCol+1 )
			.a( err.tpe3 )
			.a( flags5 & SCP_EO_ErrorAnsiECRed ? "\x1B\x5B\x30;31m" : "" )
			.a( !msgAlt.empty() ? "       " : "" )
			.a( !msgAlt.empty() ? std::string(msgAlt+"\n").c_str() : "" )
			.a( lineAt.c_str() )
			.a( flags5 & SCP_EO_ErrorAnsiECRed ? "\x1B\x5B\x30m" : "" )
			.a( (std::string(iColModded,' ')+"^").c_str() );

	if( flags5 & SCP_EO_Short ){
		z = ScpSp::strReplace( z,   "ERROR: ", "" );
		z = ScpSp::strReplace( z, "\n       ", "\n" );
	}
	return z;
}
/// Evaluates the script.
/// Parsing must have been performed.
/// \sa \ref pgParseEval
bool ScpScript2::eval2()
{
	return eval3( 0, 0 );
}
/// Evaluates the script.
/// Parsing must have been performed or 'flags4' should contain appropriate
/// flag to do it automatically here.
/// \param flags4 - flags as ORed list, fe. \ref SCP_AF_AutoParse.
/// \sa \ref pgParseEval
/// \sa \ref ScpScript2::eval2()
bool ScpScript2::eval3( int flags4, ScpErr* err )
{
	if( flags4 & SCP_AF_AutoParse ){
		if( !parse3( 0, err ) )
			return 0;
	}
	ScpErr err3, &err2 = ( err ? *err : err3 );
	if( !eval9( flags4, err2 ) ){
		ScpSp::finalizeErr( err2, ScriptCStr.first, ScriptCStr.second );
		LastError = err2;
		return 0;
	}
	if( Flags2 & SCP_SF_ShowStack ){
		std::vector<SVar>::const_iterator a;
		for( a = VarStack.begin(); a != VarStack.end(); ++a ){
			//int tpy = a->value4->getValueType__();
			//if( tpy == SCP_E2_ObjectLiteral )
			if( a->value4->getPropertyCount() ){
				std::string str = (*ScpStr("var %a = ").a(a->varname2.c_str())).c_str();
				const ScpValue* val2;
				if( !a->value4->getPropertyCount() ){
					str += "{}";
				}else{
					str += "{\n";
					for( int i=0; i < a->value4->getPropertyCount(); i++ ){
						std::string nme;
						val2 = a->value4->getPropertyAt( i, &nme );
						str += (*ScpStr("%a%a: '%a'\n")
								.a("    ")
								.a(nme.c_str())
								.a( val2->stdToString().c_str() )).c_str();
					}
					str += "}";
				}
				printf("%s\n", str.c_str() );
			}else{
				std::string str = a->value4->stdToString();
				printf("var %s = [%s]\n", a->varname2.c_str(), str.c_str() );
			}
		}
	}
	return 1;
}
bool ScpScript2::
scanUntilSequenceRecv( int dpth, size_t& ioNum, const ScpTITR& bgn,
						const ScpTITR& endd, int& mode3, SIfs& ifs2,
						ScpTITR& ended2, ScpErr& err, int mode4 )
{
	ScpTITR a = bgn;
	if( mode3 == EIDM_Els ){
		SIfdef ifd( mode4, bgn, ++a ); //EIDT_Ifdef,EIDT_IfNdef
		ifd.cond2 = ++a;
		if( ioNum < 3 ){
			err = ScpErr( bgn->tkn, SCP_EE_IfdefEof,
					"Reached end of file while looking for terminating endif." );
			return 0;
		}
		ioNum -= 3; // ifdef is made out of 3 tokens: '#', "ifdef" and condition.
		if( ifd.cond2->tpe != SCP_ET_Wrd ){
			err = ScpErr( ifd.cond2->tkn, SCP_EE_BadIfdefCond,
					"Bad ifdef conditional token, single word expected." );
			return 0;
		}
		ifs2.ifdefs2.push_back( ifd );
		++a;
	}
	for( ; a != endd; ){
		assert( ioNum > 0 );
		int mode5 = -1;
		if( ioNum >= myIfdef.size() && std::equal( myIfdef.begin(), myIfdef.end(), a ) )
			mode5 = EIDT_Ifdef;
		if( ioNum >= myIfNdef.size() && std::equal( myIfNdef.begin(), myIfNdef.end(), a ) )
			mode5 = EIDT_IfNdef;
		if( mode5 != -1 ){
			mode3 = EIDM_Els;
			SIfs ifs3;
			if(!scanUntilSequenceRecv( dpth+1, ioNum, a, endd, mode3, ifs3, a, err, mode5 ))
				return 0;
			IfDefBlocks.push_back(ifs3);//ifs2
			continue;
		}
		if( ioNum >= myEndif.size() && std::equal( myEndif.begin(), myEndif.end(), a ) ){
			SIfdef ifd( EIDT_Endif, a, endd );
			ifd.wrd = ++a;
			ifs2.ifdefs2.push_back( ifd );
			ioNum -= myEndif.size();
			if(!dpth){
				err = ScpErr( a->tkn, SCP_EE_UnxpctdEndif, "Unexpected endif." );
				return 0;
			}
			ended2 = ++a;
			mode3 = EIDM_Ifs;
			return 1;
		}else{
			++a;
			--ioNum;
		}
	}
	if( mode3 == EIDM_Els ){
		err = ScpErr( bgn->tkn, SCP_EE_UntrmtdIfdef, "Unterminated endif" );
		return 0;
	}
	return 1;
}
bool ScpScript2::preprocessCondDefs( ScpErr& err )
{
	ScpTITR a, endd = Tokens2.end(); //ScpToken
	IfDefBlocks.clear();
	if( myIfdef.empty() ){
		myIfdef.push_back( ScpToken( ScpSp("#",-1),     SCP_ET_Op ) );
		myIfdef.push_back( ScpToken( ScpSp("ifdef",-1), SCP_ET_Wrd ) );
		myEndif.push_back( ScpToken( ScpSp("#",-1),     SCP_ET_Op ) );
		myEndif.push_back( ScpToken( ScpSp("endif",-1), SCP_ET_Wrd ) );
		myIfNdef.push_back( ScpToken( ScpSp("#",-1),      SCP_ET_Op ) );
		myIfNdef.push_back( ScpToken( ScpSp("ifndef",-1), SCP_ET_Wrd ) );
	}
	{
		size_t n = Tokens2.size();
		int mode3 = EIDM_Ifs;
		SIfs ifs4;
		if( !scanUntilSequenceRecv( 0, n, Tokens2.begin(), endd, mode3, ifs4, a, err, EIDT_Endif ))
			return 0;
	}
	if( Flags2 & SCP_SF_ShowCondDefs ){
		printf("n-IfDefBlocks: %d\n", (int)IfDefBlocks.size() );
		std::vector<SIfs>::const_iterator b;
		std::vector<SIfdef>::const_iterator c;
		for( b = IfDefBlocks.begin(); b != IfDefBlocks.end(); ++b ){
			printf("n:%d\n", (int)b->ifdefs2.size() );
			for( c = b->ifdefs2.begin(); c != b->ifdefs2.end(); ++c ){
				int iCol = -1, iLnn;
				iLnn = ScpSp::convPosToLineAndCol( ScriptCStr.first,
						ScriptCStr.second, -1, c->htg->tkn.ptr, &iCol, 0 );
				std::string cnd = (c->tpe4 != EIDT_Endif ? c->cond2->tkn2.c_str() : "--");
				printf("\t%s%s %s (%d,%d)\n", c->htg->tkn2.c_str(), c->wrd->tkn2.c_str(),
						cnd.c_str(),
						iLnn+1, iCol+1 );
			}
		}
	}
	if( !applyCondDefs( err ) )
		return 0;
	return 1;
}
bool ScpScript2::applyCondDefs( ScpErr& err )
{
	std::vector<std::pair<std::string,std::string> >::const_iterator c;

	// perform erasing from reverse to prevent iterator invalidation (not true for std::list ??).
	std::vector<SIfs>::const_reverse_iterator b;
	std::vector<std::pair<std::string,std::string> >::iterator end2 = Defs.end();
	for( b = IfDefBlocks.rbegin(); b != IfDefBlocks.rend(); ++b ){
		assert( b->ifdefs2.size() >= 2 );
		assert( b->ifdefs2.rbegin()->tpe4 == EIDT_Endif );
		const SIfdef& ifdif2  = *b->ifdefs2.begin();
		const SIfdef& ifdend2 = *b->ifdefs2.rbegin();
		c = std::find_if( Defs.begin(), end2, ScpSp::PredStrStr(ifdif2.cond2->tkn2) );
		bool bTrue = ( ifdif2.tpe4 == EIDT_IfNdef ? c == end2 : c != end2 );
		if( !bTrue ){ // if condition false - cond-def not found in the list.
			ScpTITR tknBgn = ifdif2.htg; //get token begin.
			ScpTITR tknEnd = ifdend2.wrd; //get token last.
			std::advance( tknEnd, 1 );
			Tokens2.erase( tknBgn, tknEnd );
		}else{ // else erase only the tokens that make up the if-def syntax.
			ScpTITR endd = ifdend2.wrd;
			std::advance( endd, 1 );
			Tokens2.erase( ifdend2.htg, endd );
			//
			endd = ifdif2.cond2;
			std::advance( endd, 1 );
			Tokens2.erase( ifdif2.htg, endd );
		}
	}
	// once done erasing, iterators if if-def blocks became invalidatd.
	IfDefBlocks.clear();
	return 1;
}
bool ScpScript2::eval9( int flags4, ScpErr& err )
{
	ScpEvalOu ou2( err );
	ScpEval sev( ou2, this, "script_scope" );
	if( !Prgrm->eval6( sev ) )
		return 0;
	sev.clear5();
	return 1;
}
/**
	Adds host variable (also known as host object).

	All objects must be added before calling one of the eval functions.
	Depending on which member functions has been implemented on the class
	derived from ScpHostValue (derived from ScpValue), added host object may act as
	script variable or as script function (or as both).

	\param objectname - name of the variable under which to appear in the text scripts.
	\param hostvar - input variable.
	\param bOwnAndDelete - if true, input variable is "owned", meaning it will
						   be automatcally deleted.
*/
void ScpScript2::
addHostVariable( const char* varname, ScpValue* hostvar, bool bOwnAndDel )
{
	ScpErr err; //VarStack
	const ScpToken* tkn2 = hostvar->getTokenIfAny();
	assert( tkn2 );
	ScpPutScopeVar sva = { *tkn2, hostvar, err, varname, bOwnAndDel, 0, };
	bool rs2 = putScopeVariable( sva );
	assert(rs2);
}

bool ScpScript2::putScopeVariable( const ScpPutScopeVar& inp )
{
	const ScpToken* tknn = &inp.varToken;// inp.videntifier->getTokenIfAny();
	assert(tknn);
	std::string vname = ( inp.szHostVarname ? inp.szHostVarname : tknn->tkn2 );
	std::vector<SVar>::iterator a, endd = VarStack.end();
	if( (a=std::find_if( VarStack.begin(), endd, SVar(vname.c_str()) )) != endd ){
		if( a->bOwn3 )
			a->value4->dropVal();
		a->value4 = 0;
	}else{
		VarStack.push_back( SVar(vname.c_str() ) );
		a = VarStack.end();
		--a;
	}
	a->value4 = ( inp.rvalue3 ? inp.rvalue3 : new ScpDummyVal(*tknn) );
	if(inp.bGrab)
		a->value4->grabVal();
	a->bOwn3 = inp.bOwnAndDel2;
	return 1;
}
bool ScpScript2::getScopeVariable( const ScpGetScopeVar& inp )
{
	std::vector<SVar>::iterator a, endd = VarStack.end();
	if( (a=std::find_if( VarStack.begin(), endd, SVar( inp.szVarname ) )) != endd ){
		inp.sev.out4.value2 = a->value4;
		assert(a->value4);
		return 1;
	}
	inp.sev.errClear2( ScpErr( inp.valToken.tkn, SCP_EE_NoSuchVar, "Variable not found." ) );
	return 0;
}





