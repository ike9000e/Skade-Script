
#include "scipp_axb_p.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>
#include "scipp_axb_e.h"
#include "scipp_program.h"
#include "../inc/scipp/scipp_script.h"

ScpTryIdentifierExpr scpTryIdentifierExpr;
ScpTryAxBExpr        scpTryMulExpr("*","/","%");
ScpTryAdditiveExpr   scpTryAdditiveExpr;
ScpTryAsgmntExpr     scpTryAsgmntExpr;
ScpTryPrimaryExpr    scpTryPrimaryExpr;
ScpTryArgumentsExpr  scpTryArgumentsExpr;
ScpTryCallExpr       scpTryCallExpr;
ScpTryStringLiteral  scpTryStringLiteral;
ScpTryPropertyName   scpTryPropertyName;
ScpTryObjectLiteral  scpTryObjectLiteral;

bool ScpTryIdentifierExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn->tpe == SCP_ET_Wrd ){
		ScpIdentifierExpr* expr = new ScpIdentifierExpr( *inp.tokenbgn );
		expr->setOpnToken( *inp.tokenbgn );
		inp.out3.expr2   = expr;
		inp.out3.endded3 = inp.tokenbgn;// + 1;
		std::advance( inp.out3.endded3, 1 );
		return 1;
	}
	return 1;
}
bool ScpTryPrimaryExpr::tryy( const ScpParse& inp )
{
	assert( !inp.out3.expr2 );
	if( !scpTryIdentifierExpr.tryy(inp) ){ // ScpTryIdentifierExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryStringLiteral.tryy(inp) ){ // ScpTryStringLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryObjectLiteral.tryy(inp) ){ // ScpTryObjectLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	ScpTryGroupingExpr* tge = inp.prgrm->getTryGroupingExpr();
	assert(tge);
	if( !tge->tryy(inp) ){ // ScpTryGroupingExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	return 1;
}

ScpTryAxBExpr::
ScpTryAxBExpr( const char* op1,const char* op2, const char* op3, const char* op4 )
{
	Ops.push_back(op1);
	if( op2 && *op2 )
		Ops.push_back( op2 );
	if( op3 && *op3 )
		Ops.push_back( op3 );
	if( op4 && *op4 )
		Ops.push_back( op4 );
}
ScpITryParser* ScpTryAxBExpr::getLeftAxBExprParser()
{
	/// \todo here, fully quantified is to start at unary expression,
	///       ie. on multiplicatve expression here (not derived class). eg:
	///       UnaryExpression->...-> LeftHandSideExpression->...
	///       -> CallExpression -> MemberExpression -> PrimaryExpression ...
	//return &scpTryPrimaryExpr; // ScpTryPrimaryExpr*
	return &scpTryCallExpr; // ScpTryCallExpr*
}
ScpTryAdditiveExpr::ScpTryAdditiveExpr()
	: ScpTryAxBExpr("+","-")
{
}
ScpITryParser* ScpTryAdditiveExpr::getLeftAxBExprParser()
{
	return &scpTryMulExpr;
}
ScpTryAsgmntExpr::ScpTryAsgmntExpr()
	: ScpTryAxBExpr("=")
{
}
ScpITryParser* ScpTryAsgmntExpr::getLeftAxBExprParser()
{
	/// \todo more exhaustive order, eg:
	///       LeftHandSideExpression .. PrimaryExpression .. Identifier
	return &scpTryAdditiveExpr;
}
ScpTryGroupingExpr::ScpTryGroupingExpr( const ScpTryProgramParse* program2 )
{
	// this is only to ensure that grouping expr parser is managed
	// by the 'ScpTryProgramParse'. reason: grouping operator
	// stores, as a memeber variable, current token iterator position to prevent
	// infinite recursion.
	program2->getTryGroupingExpr();
}
ScpITryParser* ScpTryGroupingExpr::getInnerExprParser()
{
	/// \todo fully exhaustive would be to parse for the 'Expression'.
	return &scpTryAsgmntExpr;
}
bool ScpTryAxBExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	if( !getLeftAxBExprParser()->tryy( inp ) ) // UnaryExpression->...->PrimaryExpression.
		return 0;
	if( !inp.out3.expr2 )
			return 1;
	ScpTCITR op = inp.out3.endded3;
	if( op == inp.tokenend )
		return 1;
	if( op->tpe != SCP_ET_Op )
		return 1;
	if( op->tkn2 == ";" ){
		inp.out3.endded3 = ++op;// + 1;
		return 1;
	}
	std::vector<std::string>::const_iterator b;
	b = std::find( Ops.begin(), Ops.end(), op->tkn2.c_str() );
	if( b == Ops.end() ){ // if no operator match.
		//printf("n:%d [%s] b:%d\n", (int)Ops.size(), Ops[0].c_str(),
		//		!!dynamic_cast<ScpTryAdditiveExpr*>( this ) );
		assert( inp.out3.expr2 );
		return 1;
	}
	ScpTCITR a = op; ++a;
	if( a == inp.tokenend ){ // if EOF after operator.
		inp.errClear( ScpErr( op->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpIExpr* exprA = inp.extractExpr(); // have the left-side expression, store it.

	// Note: recursive 'tryy' call. search for the right-side expression.
	ScpParse in2( inp, a, inp.tokenend, inp.out3 );
	if( !this->tryy( in2 ) ){
		delete exprA;
		return 0;
	}
	if( !inp.out3.expr2 ){
		delete exprA;
		//printf("SCP_EE_AxBNoRhsExpr:%d\n", SCP_EE_AxBNoRhsExpr );
		inp.errClear( ScpErr( a->tkn, SCP_EE_AxBNoRhsExpr,
				"No known right-hand-side expression here." ) );
		return 0;
	}
	ScpIExpr* exprB = inp.extractExpr(); // have the right-side expression, store it.
	//
	ScpAxBExpr* axbExpr = 0;//new ScpAxBExpr( exprA, *op, exprB );
	if( op->tkn2 != "=" ){
		axbExpr = new ScpAxBExpr( exprA, *op, exprB );
	}else{
		axbExpr = new ScpAssignmentExpr( exprA, *op, exprB );
	}
	axbExpr->setOpnToken( *inp.tokenbgn );
	//
	inp.out3.expr2 = axbExpr;  //inp.out3.endded3 = inp.tokenbgn + 1;
	return 1;
}
/**
	Tries parsing for the grouping expression.
	Note: implementation of parsing of the grouping expression here must
	be done in the respect to the assignment expression, which is AxB type exression.
	that is, there is a certain requirement on recursive calls that is different in
    AxB type expressions vs grouping type expressions.

	parsing must take into account two paths:
    (1) parsing if there is a parenthese open character, and
    (2) parsing if there was no parenthese open character.
    in case of (1), after inner parsing is done, assertion must be made that
    there is the parenthese close character that follows the expression.

	NOTE: checking for recursion only possible in non-overloaded methods
	_     ('LastTokenAt'). When storing member value, try-parser must
	_     be local to program, ie. not static or global.
*/
bool ScpTryGroupingExpr::tryy( const ScpParse& inp )
{
	if( LastTokenAt == inp.tokenbgn )
		return 1;
	LastTokenAt = inp.tokenbgn;
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x28" ){ // 0x28: parentheses open character.
		// dispatch the case when there is no parenthese open, not a grouping expr.
		return getInnerExprParser()->tryy( inp );
	}else{
		ScpTCITR b = a; ++b;// + 1;
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			return 0;
		}
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !getInnerExprParser()->tryy( in2 ) ) // ScpTryAsgmntExpr or 'Expression'
			return 0;
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_GroupingNoInner,
					"Grouping expression: unknown inner expression here." ) );
			return 0;
		}
		b = inp.out3.endded3;
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			return 0;
		}
		//printf("[%s]\n", b->tkn2.c_str() );
		// make sure have the matching parenthese close character.
		if( b->tpe != SCP_ET_Op || b->tkn2 != "\x29" ){ // 0x29: parenthese close character.
			assert( inp.out3.expr2 );
			//printf("SCP_EE_NoGroupCloseHere:%d\n", SCP_EE_NoGroupCloseHere );
			inp.errClear( ScpErr( b->tkn, SCP_EE_NoGroupCloseHere,
					"Expected parenthese close here." ) );
			return 0;
		}
		inp.out3.expr2 = new ScpGroupingExpr( inp.out3.expr2, *a, *b );
		inp.out3.endded3 = b;// + 1;
		inp.out3.endded3++;
		return 1;
	}
}
bool ScpTryArgumentsExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x28" ){ // 0x28: parentheses open character.
		// there is no other case, arguments must begin with parenthese open.
		return 1;
	}
	ScpTCITR b = a; int i = 0;
	ScpExprListExpr* argsExpr = new ScpExprListExpr( *a, *a );
	bool bSuccess = 0;
	for( ;; i++ ){  // parsing for each argument in the arg-list expression.
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// only on first loop, allow parenthese close here, empty arg-list.
		if( !i && b->tpe == SCP_ET_Op && b->tkn2 == "\x29" ){ // 0x29: parenthese close chr.
			bSuccess = 1;
			break;
		}
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !scpTryAsgmntExpr.tryy( in2 ) )
			break; //bSuccess=0
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_ArgListNoAsgmntExpr,
					"Argument list: expected argument here." ) );
			break; //bSuccess=0
		}
		ScpIExpr* expr = inp.extractExpr(); // store the expression of the single argument.
		assert( expr );
		argsExpr->addExpressin( expr, 1 );
		b = inp.out3.endded3;
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// either of two here: (1) parenthese, (2) comma.
		if( b->tpe != SCP_ET_Op || (b->tkn2 != "\x29" && b->tkn2 != ",") ){ // 0x29: parenthese close character.
			inp.errClear( ScpErr( b->tkn, SCP_EE_NoCommaOrPClHere,
					"Expected comma or paren close.") );
			break; //bSuccess=0
		}
		if( b->tkn2 != "," ){
			bSuccess = 1;
			break;
		}
	}
	if(!bSuccess){
		delete argsExpr;
		argsExpr = 0;
		return 0;
	}
	inp.out3.expr2   = argsExpr;
	inp.out3.endded3 = ++b;
	return 1;
}
bool ScpTryCallExpr::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	/// \todo MemberExpression instead of primary-expr here.
	if( !scpTryPrimaryExpr.tryy(inp) ) //ScpTryPrimaryExpr*
		return 0;
	if( !inp.out3.expr2 )
		return 1;
	ScpIExpr* leftexpr = inp.extractExpr();
	ScpTCITR b = inp.out3.endded3;
	//
	if( !scpTryArgumentsExpr.tryy( ScpParse( inp, b ) ) ){ //ScpTryArgumentsExpr*
		delete leftexpr;
		return 0;
	}else if( !inp.out3.expr2 ){
		inp.out3.expr2   = leftexpr;
		inp.out3.endded3 = b;
		return 1;
	}
	ScpIExpr* arglistexpr = inp.extractExpr();
	ScpExprListExpr* arglistexpr2 = dynamic_cast<ScpExprListExpr*>( arglistexpr );
	assert(arglistexpr2);
	{
		// Try any consecutive call expression as optional.
		// Note-1: recursive calls.
		// Note-2: this must be disabled untill member expression implemented (?).
		//if( !this->tryy( inp ) ){
		//	return 0;
		//}
	}
	inp.out3.expr2 = new ScpCallExpr( *a, leftexpr, arglistexpr2 );
	return 1;
}

bool ScpTryStringLiteral::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_StrLiteral )
		return 1;
	inp.out3.expr2   = new ScpStrLiteralExpr( *a );
	inp.out3.endded3 = ++a;
	return 1;
}
bool ScpTryPropertyName::tryy( const ScpParse& inp )
{
	assert( !inp.out3.expr2 );
	if( !scpTryIdentifierExpr.tryy(inp) ){ // ScpTryIdentifierExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryStringLiteral.tryy(inp) ){ // ScpTryStringLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	// TODO: try NumericLiteral here.
	return 1;
}
bool ScpTryObjectLiteral::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn; // 0x7B, 0x7D = "{}"
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x7B" ){ // 0x7B: brace open character.
		return 1;
	}
	ScpTCITR b = a; int i = 0; ScpIExpr* exprPropName = 0, *exprAsgmnt = 0;
	ScpObjLiteralExpr* exprObjLtrl = new ScpObjLiteralExpr( *a, *a ); // ScpExprListExpr*
	bool bSuccess = 0;
	for( ;; i++ ){  // parsing for each property in the obj-literal.
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// only on first loop, allow brace close here, empty obj-literal.
		if( !i && b->tpe == SCP_ET_Op && b->tkn2 == "\x7D" ){ // 0x7D: brace close chr.
			bSuccess = 1;
			break;
		}
		// PropertyName : AssignmentExpression
		// ----------------------------------------------
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !scpTryPropertyName.tryy( in2 ) ) // ScpTryPropertyName*
			break; //bSuccess=0
		if( !inp.out3.expr2 ){   // inp.out3 === in2.out3
			inp.errClear( ScpErr( b->tkn, SCP_EE_ObjLiteralNoPropNameExpr, "Property name expected here." ) );
			break; //bSuccess=0
		}
		exprPropName = inp.extractExpr();
		ScpTCITR c = inp.out3.endded3;
		if( c == inp.tokenend ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		//int b = 0; b++;
		if( c->tpe != SCP_ET_Op || c->tkn2 != ":" ){
			inp.errClear( ScpErr( c->tkn, SCP_EE_ObjLtrlNoColonHere, "Expected colon operator here." ) );
			break; //bSuccess=0
		}
		if( ++c == inp.tokenend ){
			inp.errClear( ScpErr( (--c)->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		ScpParse in3( inp, c, inp.tokenend, inp.out3 );
		if( !scpTryAsgmntExpr.tryy( in3 ) )
			break; //bSuccess=0
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( c->tkn, SCP_EE_ObjLtrlNoAsgnmtExpr, "Expected assignment expression here." ) );
			break; //bSuccess=0
		}
		exprAsgmnt = inp.extractExpr();
		{
			assert( exprPropName && exprAsgmnt );
			ScpExprListExpr* exprAcolonB = new ScpExprListExpr( *b, *b );
			exprAcolonB->addExpressin( exprPropName, 1 );
			exprAcolonB->addExpressin( exprAsgmnt, 1 );
			exprObjLtrl->addExpressin( exprAcolonB, 1 );
			exprPropName = exprAsgmnt = 0;
			b = inp.out3.endded3;
		}
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// either of two here: (1) brace close or (2) comma.
		if( b->tpe == SCP_ET_Op && b->tkn2 == "," ){
			// check if comma is followed by a brace-close character, allow empty
			// comma on obj-literal termination.
			ScpTCITR d = b;
			if( ++d != inp.tokenend && d->tpe == SCP_ET_Op && d->tkn2 == "\x7D" ){ // 0x7D = brace close character.
				b = d;
				bSuccess = 1;
				break;
			}
			// path here continues to the next property.
		}else if( b->tpe == SCP_ET_Op && b->tkn2 == "\x7D" ){ // 0x7D = brace close character.
			bSuccess = 1;
			break;
		}else{
			inp.errClear( ScpErr( b->tkn, SCP_EE_ObjLtrlNoCommaOrBrCl,
					"Expected comma or brace close here." ) );
			break; //bSuccess=0
		}
	}
	if( !bSuccess ){
		delete exprObjLtrl;
		exprObjLtrl = 0;
		if( exprPropName ){
			delete exprPropName;
			exprPropName = 0;
		}
		if( exprAsgmnt ){
			delete exprAsgmnt;
			exprAsgmnt = 0;
		}
		assert( inp.out3.err.errpos.ptr );
		// Note: error structure already assigned before any 'break' from above.
		return 0;
	}
	inp.out3.expr2   = exprObjLtrl;
	inp.out3.endded3 = ++b;
	return 1;
}

bool ScpTryVarStmt::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tkn2 != "var" )
		return 1;
	ScpTCITR b = a; // Identifier : AssignmentExpression
	if( ++b == inp.tokenend ){
		inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpParse in2( inp, b );
	if( !scpTryIdentifierExpr.tryy(in2) )
		return 0;
	if( !inp.out3.expr2 ){
		inp.errClear( ScpErr( b->tkn, SCP_EE_VarStmtNoIdentifier, "No identifier follows 'var' keyword." ) );
		return 0;
	}
	ScpVarStatement* exprVar = new ScpVarStatement( *a, *a ); //ScpExprListExpr*
	exprVar->addExpressin( inp.extractExpr(), 1 );
	bool bSucc = 0;
	do{
		b = inp.out3.endded3;
		if( b == inp.tokenend || b->tpe != SCP_ET_Op || b->tkn2 != "=" ){
			bSucc = 1;
			break;
		}
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSucc=0
		}
		ScpParse in3( inp, b );
		if( !scpTryAsgmntExpr.tryy(in3) )
			break; //bSucc=0
		if( inp.out3.expr2 ){
			exprVar->addExpressin( inp.extractExpr(), 1 );
			b = inp.out3.endded3;
		}
		bSucc = 1;
	}while(0);
	if(!bSucc){
		delete exprVar;
		return 0;
	}
	inp.out3.expr2   = exprVar;
	inp.out3.endded3 = b;
	return 1;
}








