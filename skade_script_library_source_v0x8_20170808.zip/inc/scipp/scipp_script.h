#ifndef _SCIPP_SCRIPT_H_
#define _SCIPP_SCRIPT_H_
#include <string>

struct ScpErr; class ScpScript; class ScpValue;
struct ScpToken; struct ScpSpeOper; struct ScpSpeCall;
struct ScpEval;

// Both ScpCreateScript() functions implemented in  "scipp_script2.cpp".
ScpScript* ScpCreateScript( const char* script_text, int len, bool bCreateInternalCopy );
ScpScript* ScpCreateScript( const std::string& script_text );

/// Script parser, abstract calss.
/// In user code, use ScpCreateScript() function to create instance of this class.
/// Please see derived ScpScript2 class for more documentation details.
class ScpScript {
public:
	virtual             ~ScpScript() {}
	/// \copydoc ScpScript2::parseAndEval()
	virtual bool        parseAndEval() = 0;
	/// \copydoc ScpScript2::parse2()
	virtual bool        parse2() = 0;
	/// \copydoc ScpScript2::parse3()
	virtual bool        parse3( int flags_, ScpErr* err ) = 0;
	/// \copydoc ScpScript2::eval2()
	virtual bool        eval2() = 0;
	/// \copydoc ScpScript2::eval3()
	virtual bool        eval3( int flags_, ScpErr* err ) = 0;
	/// \copydoc ScpScript2::showMeTheError2()
	virtual void        showMeTheError2( int flags_ )const = 0;
	/// \copydoc ScpScript2::showMeTheError3()
	virtual std::string showMeTheError3( int flags_ )const = 0;
	/// \copydoc ScpScript2::addHostVariable()
	virtual void        addHostVariable( const char* objectname, ScpValue*, bool bOwnAndDel ) = 0;
	/// \copydoc ScpScript2::clear2()
	virtual void        clear2() = 0;
	/// \copydoc ScpScript2::clear3()
	virtual void        clear3( int flags_ ) = 0;
	/// \copydoc ScpScript2::setCondDef()
	virtual void        setCondDef( const char* dname, bool val ) = 0;
	/// \copydoc ScpScript2::setOptions()
	virtual void        setOptions( int flags_ ) = 0;
};

/// Flags for ScpScript::eval3().
enum{
	/**
		Can be set at the evaluation step to perform required parsing automatically.
		Normally, user calls ScpScript::parse2() then ScpScript::eval2(),
		both functions manually.
		Using this flag enables parsing and evaluating to be done in one step,
		durning ScpScript::eval2() call.
		\sa \ref pgParseEval
	*/
	SCP_AF_AutoParse = 0x1,
};
/// Flags for ScpScript::clear3().
enum{
	SCP_CF_ClearParser = 0x2,
	SCP_CF_ClearStack = 0x4,
	SCP_CF_ClearCondDefs = 0x8,
	SCP_CF_ClearAll = SCP_CF_ClearParser|SCP_CF_ClearStack|SCP_CF_ClearCondDefs,
};
/// Flags for ScpScript::setOptions().
enum{
	/// Shows tokens by printing them to the console STDOUT.
	/// Done at the moment when tokenizing finishes.
	SCP_SF_ShowTokens = 0x1,
	/// Similar to \ref SCP_SF_ShowTokens.
	SCP_SF_ShowExpressions = 0x2,
	/// Similar to \ref SCP_SF_ShowTokens.
	SCP_SF_ShowCondDefs = 0x4,
	/// Shows current stack of variables on evaluation finish.
	/// Ie. variables created in the script using the 'var' keyword.
	SCP_SF_ShowStack = 0x8,
	/// If set, error line is not trimmed down if too long.
	/// If not set, when showing the error with
	/// \ref ScpScript::showMeTheError3() ".showMeTheError3()",
	/// the original source code line, the error happened at,
	/// is trimmed down from the right, in case if it ends up being
	/// longer than internally predefined length.
	SCP_SF_NoErrLineRTrim = 0x10,
	/// If set, disables pseudo preprocessor.
	SCP_SF_DisablePreproc = 0x20,
};

/// Error types on parsing, evaluating, etc.
/// \ref ScpErr::tpe3.
enum {
	SCP_EE_Unknown = 0,
	// on tokenizer.
	SCP_EE_UnkToken = 10, SCP_EE_CommentNoClose, SCP_EE_NewlineInStrLiteral, SCP_EE_StrLiteralNoClose,
	SCP_EE_BadNumLiteral,
	// on pseudo preprocessing.
	SCP_EE_UnxpctdEndif = 50, SCP_EE_UntrmtdIfdef, SCP_EE_IfdefEof, SCP_EE_BadIfdefCond,
	// on parser.
	SCP_EE_EofOnParse = 100, SCP_EE_TokenSeqUnknown, SCP_EE_AxBNoRhsExpr, SCP_EE_NoGroupCloseHere,
	SCP_EE_GroupingNoInner, SCP_EE_ArgListNoAsgmntExpr, SCP_EE_NoCommaOrPClHere, SCP_EE_ObjLiteralNoPropNameExpr,
	SCP_EE_ObjLtrlNoColonHere, SCP_EE_ObjLtrlNoAsgnmtExpr, SCP_EE_ObjLtrlNoCommaOrBrCl,
	SCP_EE_VarStmtNoIdentifier,
	// on evaluator.
	SCP_EE_UserEvalNull = 200, SCP_EE_NoSuchHostObject2, SCP_EE_NoSuchHostObject3, SCP_EE_NoSuchHostObject4,
	SCP_EE_NoSuchHostObject5, SCP_EE_NoSuchHostOper, SCP_EE_UnkErrOnUsrCall, SCP_EE_UsrCallNotImpl,
	SCP_EE_OperatorNoImpl, SCP_EE_UnexpectedOper, SCP_EE_NoSuchVar,
};

/// Flags for ScpScript::showMeTheError2() and ScpScript::showMeTheError3().
enum{
	/// If set, shortens textual error from the left by not including
	/// error label and text indent.
	SCP_EO_Short = 0x1,
	/// If set, uses ansi color codes and makes selected part of the text red.
	SCP_EO_ErrorAnsiECRed = 0x2,
};


/// Base for all values.
/// In user code, host objects should be derived from ScpHostValue class instead.
/// Please note that some of it's global functions are only for internal purpose
/// and some are not alowed to be used at all.
class ScpValue {
public:
	;                       ScpValue( const ScpToken* );
	virtual                 ~ScpValue() = 0;
	void                    grabVal();
	bool                    dropVal();
	virtual int             getValueType()const; //SCP_E2_Unknown
	virtual std::string     strPrint3()const;
	const ScpToken*         getTokenIfAny()const {return Token2;}
	ScpToken*               getTokenIfAny() {return Token2;}
	//
	virtual std::string     stdToString()const {return "";}
	virtual double          stdToDouble()const {return 0.0;}
	virtual bool            evalOperatorMul( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorDiv( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorAdd( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorSub( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorPercent( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorAssign( const ScpSpeOper& inp );
	virtual bool            evalFunctionCall( const ScpSpeCall& inp );
	//
	virtual int             getPropertyCount()const {return 0;}
	virtual const ScpValue* getPropertyAt( int indexAt, std::string* strPropertyName )const;
	virtual const ScpValue* getPropertyByName( const char* szVarname )const {return 0;}
private:
    void genericOperError( const ScpSpeOper& inp, const char* szOper )const;
private:
	ScpToken* Token2;
	int RefCnt;
};
/// Base class for host objects derived in the user code.
/// Please see documentation of base ScpValue class for the
/// selection of virtual member functions
/// that need to be reimplemented to provide desired functionality.
class ScpHostValue : public ScpValue {
public:
	ScpHostValue() : ScpValue(0) {}
	virtual int getValueType()const; //SCP_E2_HostObject
};

/// Structure used when implementing the operator functions.
/// For example: ScpValue::evalOperatorMul(), ScpValue::evalOperatorSub(),
/// ScpValue::evalOperatorAssign(), and others.
struct ScpSpeOper {
	/// Used internally.
	const ScpEval&  sev;
	/// Value that is on the right hand side of the operator in question.
	const ScpValue* otherr;
	ScpValue**      result2;  // repeat of 'sev.out4.value2' as a pointer.
};

/// Parameters when implementing the function call.
/// Used in the member function: \code
/// virtual bool ScpValue::evalFunctionCall( const ScpSpeCall& inp );
/// \endcode
struct ScpSpeCall {
	/// Used internally.
	const ScpEval&        sev;
	/// Number of arguments in the 'argv2' array.
	int                   argc2;
	/// Array of function call arguments.
	const ScpValue*const* argv2;
	/// Return value of the function call.
	/// I.e. the value that is returned to the script from the user function
	/// evaluation in the C++. Return value from the derived
	/// ScpHostValue::evalFunctionCall() should be always boolean *true* (unless error). \n
	///
	/// \note NOTE: return value must not be set to one of the call arguments directly
	///       (i.e. using pointers from *argv2* member). Doing so would cause segmentation fault.
	///
	/// \note NOTE: currently (v0.7) only way of returning value is described below.
	///
	/// \n
	/// Assuming *sc* is declared like this:
	/// \code
	///     const ScpSpeCall& sc
	/// \endcode
	/// new value should be created using the *new* operator and
	/// its pointer stored at location *sc.result2* points to:
	/// \code
	///     *sc.result2 = new MyHostVar( 123 );
	/// \endcode
	/// Type *MyHostVar* should be class that is used as
	/// the host variable (class derived from ScpHostValue
	/// (which in turn is derived from ScpValue)).
	/// N.b. this can be of the same type that overrided ScpHostValue::evalFunctionCall()
	/// function is member of and/or is being called.
	ScpValue**            result2;  // repeat of 'sev.out4.value2' as a pointer.
};

#endif //_SCIPP_SCRIPT_H_
