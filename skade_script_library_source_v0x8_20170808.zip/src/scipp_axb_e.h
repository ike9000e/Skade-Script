
#ifndef _SCIPP_AXB_E_H_
#define _SCIPP_AXB_E_H_
#include "scipp_expr.h"
#include <vector>

class ScpIdentifierExpr : public ScpIExpr {
public:
	;                     ScpIdentifierExpr( const ScpToken& tkn );
	virtual               ~ScpIdentifierExpr() {}
	virtual bool          eval6( const ScpEval& in );
	virtual std::string   strPrint2( const ScpPrnt& inp )const;
};

class ScpAxBExpr : public ScpIExpr {
public:
	;                   ScpAxBExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr );
	virtual             ~ScpAxBExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;

private:
	ScpIExpr* LeftExpr, *RightExpr;
	ScpToken* OpTkn;
};
class ScpAssignmentExpr : public ScpAxBExpr {
public:
	ScpAssignmentExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr );
	virtual bool eval6( const ScpEval& inp );
};

class ScpGroupingExpr : public ScpIExpr {
public:
	;                   ScpGroupingExpr( ScpIExpr* innerExpr, const ScpToken& opn2, const ScpToken& close2 );
	virtual             ~ScpGroupingExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	ScpIExpr* InnerExpr;
};
/// Holds expressions as internal list.
/// Used for example to hold expressions of argument list.
class ScpExprListExpr : public ScpIExpr {
public:
	;                   ScpExprListExpr( const ScpToken& opn2, const ScpToken& close2 );
	virtual             ~ScpExprListExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
	void                addExpressin( ScpIExpr* exprr, bool bOwnAndDel );
	int                 getExprCount()const {return (int)ArgList.size();}
	ScpIExpr*           getExprAt( int idx );
	virtual const char* getExprListName()const {return "ARGs";}
private:
	std::vector<ScpIExpr*> ArgList;
};
class ScpCallExpr : public ScpIExpr {
public:
	;                   ScpCallExpr( const ScpToken& opn2, ScpIExpr* LeftExpr_, ScpExprListExpr* ArgsExpr_ );
	virtual             ~ScpCallExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	ScpIExpr* LeftExpr;
	ScpExprListExpr* ArgsExpr;
};

class ScpStrLiteralExpr : public ScpIExpr {
public:
	;                   ScpStrLiteralExpr( const ScpToken& tkn_ );
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	std::string pseudoevalQuotedStr( const char* inp, int len );
};

class ScpNumericLiteralExpr : public ScpIExpr {
public:
	;                   ScpNumericLiteralExpr( const ScpToken& tkn_ );
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
};

class ScpObjLiteralExpr : public ScpExprListExpr {
public:
	;                   ScpObjLiteralExpr( const ScpToken& opn2, const ScpToken& close2 );
	virtual bool        eval6( const ScpEval& inp );
	virtual const char* getExprListName()const {return "Object-Literal";}
};

class ScpVarStatement : public ScpExprListExpr {
public:
	;                   ScpVarStatement( const ScpToken& opn2, const ScpToken& close2 );
	virtual bool        eval6( const ScpEval& inp );
	virtual const char* getExprListName()const {return "Var-Statement";}
};

#endif // _SCIPP_AXB_E_H_
