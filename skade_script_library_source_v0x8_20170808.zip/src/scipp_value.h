
#ifndef _SCIPP_VALUE_H_
#define _SCIPP_VALUE_H_
#include <string>
#include <vector>
#include "../inc/scipp/scipp_script.h"

struct ScpEval; struct ScpToken; class ScpHostObject; struct ScpSpeOper;
struct ScpSpeCall;

enum{
	/// Value types returned by member function ScpValue::getValueType() and
	/// it's overrides.
	SCP_E2_Unknown = 0,
	/// Used by ScpStrVal.
	SCP_E2_String,
	SCP_E2_Number,
	/// Used by ScpHostValue.
	SCP_E2_HostObject,
	/// Used by ScpObjLiteralVal.
	SCP_E2_ObjectLiteral,
};

/// For default value purposes.
/// Aka. void value, eg. when host object call returns no value or default
/// on var-statement.
class ScpDummyVal : public ScpValue {
public:
	ScpDummyVal( const ScpToken& );
};

/// List of values *value*.
/// Used fe. as an evaluated function argument list.
class ScpValListVal : public ScpValue {
public:
	;               ScpValListVal( const ScpToken& );
	virtual         ~ScpValListVal();
	void            addVal( ScpValue* inp, bool bOwnAndDel, const char* szVarname = 0 );
	int             getValCount()const;
	ScpValue*       getValAt( int idx, std::string* nameOut = 0 );
	const ScpValue* getValAt( int idx, std::string* nameOut = 0 )const;
	const ScpValue* findValByName( const char* name_ )const;
private:
	struct SVal{
		ScpValue*   value5;
		bool        bOwn;
		std::string name3;
	};
	std::vector<SVal> Values2;
};
/// The object literal value.
class ScpObjLiteralVal : public ScpValListVal {
public:
	;                       ScpObjLiteralVal( const ScpToken& tkn ) : ScpValListVal(tkn) {}
	virtual int             getValueType()const {return SCP_E2_ObjectLiteral;}
	virtual int             getPropertyCount()const;
	virtual const ScpValue* getPropertyAt( int indexAt, std::string* strPropertyName )const;
	virtual const ScpValue* getPropertyByName( const char* szVarname )const;
};

/// The string literal value.
class ScpStrVal : public ScpValue {
public:
	;                       ScpStrVal( const ScpToken&, const char* szStr, int len );
	virtual int             getValueType()const {return SCP_E2_String;}
	virtual std::string     stdToString()const {return Str;}
	virtual double          stdToDouble()const;
	virtual bool            evalOperatorAdd( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorAssign( const ScpSpeOper& inp );
private:
	std::string Str;
};

/// The numeric literal value.
class ScpNumVal : public ScpValue {
public:
	;                       ScpNumVal( const ScpToken&, const char* szStr, int len );
	;                       ScpNumVal( const ScpToken&, double inp );
	const double&           getInternalValue()const {return Value2;}
	virtual int             getValueType()const {return SCP_E2_Number;}
	virtual std::string     stdToString()const;
	virtual double          stdToDouble()const {return Value2;}
	virtual bool            evalOperatorAssign( const ScpSpeOper& inp );
	virtual bool            evalOperatorMul( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorDiv( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorAdd( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorSub( const ScpSpeOper& inp )const;
	virtual bool            evalOperatorPercent( const ScpSpeOper& inp )const;
private:
	double Value2;
};

struct ScpValAutoPtr {
	;                ScpValAutoPtr( ScpValue* inp=0, bool bGrab_=0 );
	virtual          ~ScpValAutoPtr() {if(Ptr) Ptr->dropVal(); Ptr = 0;}
	ScpValue*        operator()()const {return Ptr;}
	void             setPointer( ScpValue* inp, bool bGrab_ );
private:
	ScpValue* Ptr;
};

#endif // _SCIPP_VALUE_H_
