#ifndef _SCIPP_EXPR_H_
#define _SCIPP_EXPR_H_
#include <string>
#include <vector>

struct ScpEval; class ScpValue; struct ScpToken; struct ScpPrnt;
struct ScpEvalOu; struct ScpErr; class ScpScope;
class ScpHostObject; class ScpValListVal;
struct ScpSpeCall; struct ScpEvalBuiltinCall;

/// Flags for ScpCtrlFlowStmt().
enum{
	SCP_ECF_None = 0,
	SCP_ECF_Break,
	SCP_ECF_Continue,
	SCP_ECF_Return,
	SCP_ECF_EmptyTrue,
};

/// Base class for all expressions.
class ScpIExpr {
public:
	;                     ScpIExpr( const char* name2, const ScpToken& );
	virtual               ~ScpIExpr();
	virtual bool          eval6( const ScpEval& inp ) = 0;
	virtual std::string   strPrint2( const ScpPrnt& inp )const;
	void                  setExprName( const char* sz ) {ExprName = sz;}
	const char*           getExprName()const {return ExprName.c_str();}
	ScpIExpr&             setOpnToken( const ScpToken& inp );
	const ScpToken&       getOpnToken()const;
	ScpIExpr&             setEnclosingTokens( const ScpToken& ltkn, const ScpToken& rtkn );
	const ScpToken*       getEnclosingTokens( bool bGetSecondInstead )const;
	virtual std::vector<ScpIExpr*>* getInnerExpressionsIfAny();
	virtual int           getCtrlFlowTypeIfAny()const {return SCP_ECF_None;}
	static int            getStaticExpressionCount();
private:
	std::string ExprName;
	ScpToken* OpToken;
	std::pair<ScpToken*,ScpToken*> EnclosingIfAny;
	static const bool bCountStaticIExpression;
	static int  nStaticIExpressionCount;
};
/// Params for strPrint2() methods.
struct ScpPrnt{
	std::string tbs;
	ScpPrnt( const std::string& tbs_ ) : tbs(tbs_) {}
	ScpPrnt& addTabs( int num = 1 );
};

struct ScpEbcSpeCall
{
	const ScpSpeCall&   sevc2;
	const char*         szBltnName;
	const ScpToken&     tkn3;
};

/// Params on evaluate. Eg. \ref ScpIExpr::eval6() ".eval6()".
struct ScpEval {
	ScpEvalOu&          out4;
	ScpScope*           scope2;
	ScpValue*           lvalRef;
	ScpEvalBuiltinCall* ebc2;
	;          ScpEval( const ScpEval& inp, ScpEvalOu& out_ );
	;          ScpEval( ScpEvalOu& out_, ScpScope* scope_, const char* szScopeName );
	ScpValue*  extractValue()const;
	void       clear5()const;
	void       errClear2( const ScpErr& err_ )const;
private:
	ScpEval();
	ScpEval( const ScpEval& other );
	void operator=( const ScpEval& other );
};
/// Output params on evaluate. Eg. \ref ScpIExpr::eval6() ".eval6()".
struct ScpEvalOu{
	ScpValue*    value2;
	ScpErr&      err4;
	ScpValue*    lvalRef2;
	ScpEvalOu( ScpErr& err_ ) : value2(0), err4(err_), lvalRef2(0) {}
};
struct ScpEvalPair{
	const char*     nameA, *nameB;
	const ScpToken& oper;
	/// On error, number that tells which part of the input is the problem.
	/// 0: 'lval', 1: 'rval' or -1: operator.
	int*            iErrIs;
	int*            eErr;
	/// Output value, result of the evaluation.
	ScpValue**      val2;
	ScpValue*       lval, *rval;
};
/*
/// Call value and arg list. First value is the call expression itself.
/// Values starting at index 1 construct argument list.
struct ScpEvalCallAndArgs {
	int*                      iErrIs, *eErr;
	/// Output value, result of the evaluation.
	ScpValue**                val4;
	const ScpToken&           tokenAt;
	ScpValListVal&            argvals2;
};//*/

//struct ScpEvalHoObAsgn {
//	ScpValue*   lvalue2;
//	const char* szPrpName;
//	ScpValue*   asgnVal;
//	ScpErr&     err5;
//};
struct ScpPutScopeVar {
	const ScpToken&  varToken;
	ScpValue*        rvalue3;
	ScpErr&          err;
	const char*      szHostVarname;
	bool             bOwnAndDel2, bGrab;

	ScpPutScopeVar(
		const ScpToken&  varToken_,
		ScpValue*        rvalue3_,
		ScpErr&          err_,
		const char*      szHostVarname_,
		bool             bOwnAndDel2_,
		bool             bGrab_
	);

};

struct ScpGetScopeVar {
	const char*      szVarname;
	const ScpToken&  valToken;
	const ScpEval&   sev;
};

#endif // _SCIPP_EXPR_H_


