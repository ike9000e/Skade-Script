
#ifndef SCIPP_BUILTINS_H_INCLUDED
#define SCIPP_BUILTINS_H_INCLUDED
#include <string>
#include <vector>
#include "scipp_tryparser.h"

class ScpEval;

/**
	Helper class for evaluating built-ins (aka. builtin functions).
	Eg. *sc_len*, *sc_substr*, etc.

	*	sc_eq, sc_lt, sc_le, sc_not
	*	sc_len, sc_substr
	*	sc_print, sc_flush
	*	sc_intval, sc_floatval, sc_strval
	*	sc_min, sc_max, sc_abs
	*	sc_sqrt, sc_pow
	*	sc_modf, sc_fmod
	*	sc_divmod
	*	sc_list
		sc_sprintf, sc_printf
		sc_array, sc_append, sc_insert, sc_slice, sc_erase, sc_setattr, sc_getattr
		sc_strstr, sc_stristr, sc_str_find
		sc_strpos, strrpos, stripos, strripos, sc_index_of
		sc_strchr, sc_strrchr, sc_strpbrk
		sc_dirname, sc_basename, sc_splitext, splitpath
		sc_raw_input
		sc_trim, sc_ltrim, sc_rtrim
		sc_implode, sc_explode
		sc_strtolower, strtoupper, str_replace, str_pad
		sc_log
		sc_random
		sc_getenv
		sc_gettickcount
		sc_gettime (time_t)
		sc_ord, sc_chr
		sc_bit32and, sc_bit32or, sc_bit32xor //bit32.band -> Lua
		sc_is_number, sc_is_string
		sc_
*/
struct ScpBuiltins : public ScpEvalBuiltinCall
{
	virtual bool     evalBuiltinCall( const ScpEbcSpeCall& inp );
private:
	static void genericBadArgcError( int nExpected, int nGot, const ScpToken& tknn, const ScpEval& outp );
	static void genericBadArgTypeError( int nArgIdx, const char* szExpectedTy, const ScpToken& tknn, const ScpEval& outp );
};


#endif // SCIPP_BUILTINS_H_INCLUDED
