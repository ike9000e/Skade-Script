
#include "scipp_axb_p.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>
#include "scipp_axb_e.h"
#include "scipp_program.h"
#include "../inc/scipp/scipp_script.h"

ScpTryIdentifierExpr scpTryIdentifierExpr;
ScpTryAxBExpr        scpTryMulExpr("*","/","%");
ScpTryAdditiveExpr   scpTryAdditiveExpr;
ScpTryAsgmntExpr     scpTryAsgmntExpr;
ScpTryPrimaryExpr    scpTryPrimaryExpr;
ScpTryArgumentsExpr  scpTryArgumentsExpr;
ScpTryCallExpr       scpTryCallExpr;
ScpTryStringLiteral  scpTryStringLiteral;
ScpTryNumericLiteral scpTryNumericLiteral;
ScpTryPropertyName   scpTryPropertyName;
ScpTryObjectLiteral  scpTryObjectLiteral;
ScpTryBlockStmt      scpTryBlockStmt;
ScpTryExpressionStmt scpTryExpressionStmt;
ScpTryFIterationStmt scpTryTheIfStmt(!!"if-only");
ScpTryTheElseStmt    scpTryTheElseStmt;

bool ScpTryIdentifierExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn->tpe == SCP_ET_Wrd ){
		ScpTCITR a = inp.tokenbgn;
		//if( a->tkn2 == "sc_eq" )
		/// \todo Add documtnation entry that all identifiers that
		///       start with 'sc_' text are reserved for builtins.
		if( a->tkn2.substr(0,3) == "sc_" ){ // eg. "sc_eq()"
			inp.out3.expr2 = new ScpBuiltinFuncIdentifierExpr( *a );
			inp.out3.endded3 = ++a;
		}else{
			ScpIdentifierExpr* expr = new ScpIdentifierExpr( *inp.tokenbgn );
			expr->setOpnToken( *inp.tokenbgn );
			inp.out3.expr2   = expr;
			inp.out3.endded3 = inp.tokenbgn;// + 1;
			std::advance( inp.out3.endded3, 1 );
		}
		return 1;
	}
	return 1;
}
bool ScpTryPrimaryExpr::tryy( const ScpParse& inp )
{
	assert( !inp.out3.expr2 );
	if( !scpTryIdentifierExpr.tryy(inp) ){ // ScpTryIdentifierExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryStringLiteral.tryy(inp) ){ // ScpTryStringLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryNumericLiteral.tryy(inp) ){ // ScpTryNumericLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryObjectLiteral.tryy(inp) ){ // ScpTryObjectLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	ScpTryGroupingExpr* tge = inp.prgrm->getTheTryGroupingExpr();
	assert(tge);
	if( !tge->tryy(inp) ){ // ScpTryGroupingExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	return 1;
}

ScpTryAxBExpr::
ScpTryAxBExpr( const char* op1,const char* op2, const char* op3, const char* op4 )
{
	Ops.push_back(op1);
	if( op2 && *op2 )
		Ops.push_back( op2 );
	if( op3 && *op3 )
		Ops.push_back( op3 );
	if( op4 && *op4 )
		Ops.push_back( op4 );
}
void ScpTryAxBExpr::addOperator( const char* op2 )
{
	Ops.push_back( op2 );
}
ScpITryParser* ScpTryAxBExpr::getLeftAxBExprParser()
{
	/// \todo here, fully quantified is to start at unary expression,
	///       ie. on multiplicatve expression here (not derived class). eg:
	///       UnaryExpression->...-> LeftHandSideExpression->...
	///       -> CallExpression -> MemberExpression -> PrimaryExpression ...
	//return &scpTryPrimaryExpr; // ScpTryPrimaryExpr*
	return &scpTryCallExpr; // ScpTryCallExpr*
}
ScpTryAdditiveExpr::ScpTryAdditiveExpr()
	: ScpTryAxBExpr("+","-")
{
	addOperator( ScpSp::OpCmpndAdd );
	addOperator( ScpSp::OpCmpndSub );
	addOperator( ScpSp::OpCmpndMul );
	addOperator( ScpSp::OpCmpndDiv );
	addOperator( ScpSp::OpCmpndPercent );
}
ScpITryParser* ScpTryAdditiveExpr::getLeftAxBExprParser()
{
	return &scpTryMulExpr;
}
ScpTryAsgmntExpr::ScpTryAsgmntExpr()
	: ScpTryAxBExpr("=")
{
}
ScpITryParser* ScpTryAsgmntExpr::getLeftAxBExprParser()
{
	/// \todo more exhaustive order, eg:
	///       LeftHandSideExpression .. PrimaryExpression .. Identifier
	return &scpTryAdditiveExpr;
}
ScpTryGroupingExpr::ScpTryGroupingExpr( const ScpTryProgramParse* program2 )
{
	// Referencing the program, in this constructor here,
	// is only to ensure that this grouping expression parser is managed
	// by the 'ScpTryProgramParse' object itself.
	// Reason: to prevent infinite recursion. Grouping operator
	// stores, as a memeber variable, current token iterator position.
	const ScpTryGroupingExpr* tge = program2->getTheTryGroupingExpr();
	assert( this == tge || !tge );
}
ScpITryParser* ScpTryGroupingExpr::getInnerExprParser()
{
	/// \todo fully exhaustive would be to parse for the
	///       'Expression' [NQlXrdN2o9w0].
	return &scpTryAsgmntExpr;
}
bool ScpTryAxBExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	if( !getLeftAxBExprParser()->tryy( inp ) ) // UnaryExpression->...->PrimaryExpression.
		return 0;
	if( !inp.out3.expr2 )
		return 1;
	ScpTCITR op = inp.out3.endded3;
	if( op == inp.tokenend )
		return 1;
	if( op->tpe != SCP_ET_Op )
		return 1;
	if( op->tkn2 == ";" ){
		inp.out3.endded3 = ++op;// + 1;
		return 1;
	}
	std::vector<std::string>::const_iterator b;
	b = std::find( Ops.begin(), Ops.end(), op->tkn2.c_str() );
	if( b == Ops.end() ){ // if no operator match.
		//printf("n:%d [%s] b:%d\n", (int)Ops.size(), Ops[0].c_str(),
		//		!!dynamic_cast<ScpTryAdditiveExpr*>( this ) );
		assert( inp.out3.expr2 );
		return 1;
	}
	ScpTCITR a = op; ++a;
	if( a == inp.tokenend ){ // if EOF after the operator.
		inp.errClear( ScpErr( op->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpIExpr* exprA = inp.extractExpr(); // have the left-side expression, store it.

	// Note: recursive 'tryy' call. search for the right-side expression.
	ScpParse in2( inp, a, inp.tokenend, inp.out3 );
	if( !this->tryy( in2 ) ){
		delete exprA;
		return 0;
	}
	if( !inp.out3.expr2 ){
		delete exprA;
		//printf("SCP_EE_AxBNoRhsExpr:%d\n", SCP_EE_AxBNoRhsExpr );
		inp.errClear( ScpErr( a->tkn, SCP_EE_AxBNoRhsExpr,
				"No known right-hand-side expression here." ) );
		return 0;
	}
	ScpIExpr* exprB = inp.extractExpr(); // have the right-side expression, store it.
	//
	ScpAxBExpr* axbExpr = 0;
	if( op->tkn2 != "=" ){
		axbExpr = new ScpAxBExpr( exprA, *op, exprB );
	}else{
		axbExpr = new ScpAssignmentExpr( exprA, *op, exprB );
	}
	axbExpr->setOpnToken( *inp.tokenbgn );
	//
	inp.out3.expr2 = axbExpr;  //inp.out3.endded3 = inp.tokenbgn + 1;
	return 1;
}
/**
	Tries parsing for the grouping expression.
	Note: implementation of parsing of the grouping expression here must
	be done in the respect to the assignment expression, which is AxB type exression.
	that is, there is a certain requirement on recursive calls that is different in
	AxB type expressions vs grouping type expressions.

	parsing must take into account two paths:
	(1) parsing if there is a parenthese open character, and
	(2) parsing if there was no parenthese open character.
	in case of (1), after inner parsing is done, assertion must be made that
	there is the parenthese close character that follows the expression.

	NOTE: checking for recursion only possible in non-overloaded methods
	_     ('LastTokenAt'). When storing member value, try-parser must
	_     be local to the program, ie. not static or global.
*/
bool ScpTryGroupingExpr::tryy( const ScpParse& inp )
{
	if( LastTokenAt == inp.tokenbgn )
		return 1;
	LastTokenAt = inp.tokenbgn;
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x28" ){ // 0x28: parentheses open character.
		// dispatch the case when there is no parenthese open,
		// not a grouping expr.
		return getInnerExprParser()->tryy( inp );
	}else{
		ScpTCITR b = a;
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			return 0;
		}
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !getInnerExprParser()->tryy( in2 ) ) // ScpTryAsgmntExpr or 'Expression'
			return 0;
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_GroupingNoInner,
					"Grouping expression: unknown inner expression here." ) );
			return 0;
		}
		b = inp.out3.endded3;
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			return 0;
		}
		//printf("[%s]\n", b->tkn2.c_str() );
		// make sure have the matching parenthese close character.
		if( b->tpe != SCP_ET_Op || b->tkn2 != "\x29" ){ // 0x29: parenthese close character.
			assert( inp.out3.expr2 );
			//printf("SCP_EE_NoGroupCloseHere:%d\n", SCP_EE_NoGroupCloseHere );
			inp.errClear( ScpErr( b->tkn, SCP_EE_NoGroupCloseHere,
					"Expected parenthese close here." ) );
			return 0;
		}
		inp.out3.expr2 = new ScpGroupingExpr( inp.out3.expr2, *a, *b );
		inp.out3.endded3 = b;// + 1;
		inp.out3.endded3++;
		return 1;
	}
}
/// Returns iterator addressing closing brace ('tknClose') or 'endd'.
/// It is assumed that initial, opening brace, has been consumed.
/// Typically, 'bgn' should address first token past the opening
/// brace ('tknOpen').
ScpTCITR ScpTryGroupingExpr::
scanForBraceLv1Rcv( ScpTCITR bgn, const ScpTCITR& endd,
				const char* tknOpen, const char* tknClose )
{
	ScpTCITR a = bgn;
	for(; a != endd; ++a ){
		if( a->tpe == SCP_ET_Op && a->tkn2 == tknOpen ){
			if(endd == (a = scanForBraceLv1Rcv( ++a, endd, tknOpen, tknClose )))
				break;
		}else if( a->tpe == SCP_ET_Op && a->tkn2 == tknClose ){
			break;
		}
	}
	return a;
}

bool ScpTryArgumentsExpr::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn == inp.tokenend )
		return 1;
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x28" ){ // 0x28: parentheses open character.
		// there is no other case, arguments must begin with parenthese open.
		return 1;
	}
	ScpTCITR b = a; int i = 0;
	ScpExprListExpr* argsExpr = new ScpExprListExpr( *a, *a );
	bool bSuccess = 0;
	for( ;; i++ ){  // parsing for each argument in the arg-list expression.
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// only on first loop, allow parenthese close here, empty arg-list.
		if( !i && b->tpe == SCP_ET_Op && b->tkn2 == "\x29" ){ // 0x29: parenthese close chr.
			bSuccess = 1;
			break;
		}
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !scpTryAsgmntExpr.tryy( in2 ) )
			break; //bSuccess=0
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_ArgListNoAsgmntExpr,
					"Argument list: expected argument here." ) );
			break; //bSuccess=0
		}
		ScpIExpr* expr = inp.extractExpr(); // store the expression of the single argument.
		assert( expr );
		argsExpr->addExpressin( expr, 1 );
		b = inp.out3.endded3;
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// either of two here: (1) parenthese, (2) comma.
		if( b->tpe != SCP_ET_Op || (b->tkn2 != "\x29" && b->tkn2 != ",") ){ // 0x29: parenthese close character.
			inp.errClear( ScpErr( b->tkn, SCP_EE_NoCommaOrPClHere,
					"Expected comma or paren close.") );
			break; //bSuccess=0
		}
		if( b->tkn2 != "," ){
			bSuccess = 1;
			break;
		}
	}
	if(!bSuccess){
		delete argsExpr;
		argsExpr = 0;
		return 0;
	}
	inp.out3.expr2   = argsExpr;
	inp.out3.endded3 = ++b;
	return 1;
}
bool ScpTryCallExpr::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	/// \todo MemberExpression instead of primary-expr here, on
	///       call expression parsing.
	if( !scpTryPrimaryExpr.tryy(inp) ) //ScpTryPrimaryExpr*
		return 0;
	if( !inp.out3.expr2 )
		return 1;
	ScpIExpr* leftexpr = inp.extractExpr();
	ScpTCITR b = inp.out3.endded3;
	//
	if( !scpTryArgumentsExpr.tryy( ScpParse( inp, b ) ) ){ //ScpTryArgumentsExpr*
		delete leftexpr;
		return 0;
	}else if( !inp.out3.expr2 ){
		inp.out3.expr2   = leftexpr;
		inp.out3.endded3 = b;
		return 1;
	}
	ScpIExpr* arglistexpr = inp.extractExpr();
	ScpExprListExpr* arglistexpr2 = dynamic_cast<ScpExprListExpr*>( arglistexpr );
	assert(arglistexpr2);
	{
		// Try any consecutive call expression as optional.
		// Note-1: recursive calls.
		// Note-2: this must be disabled untill member expression implemented (?).
		//if( !this->tryy( inp ) ){
		//	return 0;
		//}
	}
	inp.out3.expr2 = new ScpCallExpr( *a, leftexpr, arglistexpr2 );
	return 1;
}

bool ScpTryStringLiteral::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_StrLiteral )
		return 1;
	inp.out3.expr2   = new ScpStrLiteralExpr( *a );
	inp.out3.endded3 = ++a;
	return 1;
}
bool ScpTryNumericLiteral::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_NumericLiteral )
		return 1;
	inp.out3.expr2   = new ScpNumericLiteralExpr( *a );
	inp.out3.endded3 = ++a;
	return 1;
}
bool ScpTryPropertyName::tryy( const ScpParse& inp )
{
	assert( !inp.out3.expr2 );
	if( !scpTryIdentifierExpr.tryy(inp) ){ // ScpTryIdentifierExpr*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	if( !scpTryStringLiteral.tryy(inp) ){ // ScpTryStringLiteral*
		return 0;
	}else if( inp.out3.expr2 ){
		return 1;
	}
	// TODO: try NumericLiteral here.
	return 1;
}
bool ScpTryObjectLiteral::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn; // 0x7B, 0x7D = "{}"
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x7B" ){ // 0x7B: brace open character.
		return 1;
	}
	ScpTCITR b = a; int i = 0; ScpIExpr* exprPropName = 0, *exprAsgmnt = 0;
	ScpObjLiteralExpr* exprObjLtrl = new ScpObjLiteralExpr( *a, *a ); // ScpExprListExpr*
	bool bSuccess = 0;
	for( ;; i++ ){  // parsing for each property in the obj-literal.
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// only on first loop, allow brace close here, empty obj-literal.
		if( !i && b->tpe == SCP_ET_Op && b->tkn2 == "\x7D" ){ // 0x7D: brace close chr.
			bSuccess = 1;
			break;
		}
		// PropertyName : AssignmentExpression
		// ----------------------------------------------
		ScpParse in2( inp, b, inp.tokenend, inp.out3 );
		if( !scpTryPropertyName.tryy( in2 ) ) // ScpTryPropertyName*
			break; //bSuccess=0
		if( !inp.out3.expr2 ){   // inp.out3 === in2.out3
			inp.errClear( ScpErr( b->tkn, SCP_EE_ObjLiteralNoPropNameExpr, "Property name expected here." ) );
			break; //bSuccess=0
		}
		exprPropName = inp.extractExpr();
		ScpTCITR c = inp.out3.endded3;
		if( c == inp.tokenend ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		//int b = 0; b++;
		if( c->tpe != SCP_ET_Op || c->tkn2 != ":" ){
			inp.errClear( ScpErr( c->tkn, SCP_EE_ObjLtrlNoColonHere, "Expected colon operator here." ) );
			break; //bSuccess=0
		}
		if( ++c == inp.tokenend ){
			inp.errClear( ScpErr( (--c)->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		ScpParse in3( inp, c, inp.tokenend, inp.out3 );
		if( !scpTryAsgmntExpr.tryy( in3 ) )
			break; //bSuccess=0
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( c->tkn, SCP_EE_ObjLtrlNoAsgnmtExpr, "Expected assignment expression here." ) );
			break; //bSuccess=0
		}
		exprAsgmnt = inp.extractExpr();
		{
			assert( exprPropName && exprAsgmnt );
			ScpExprListExpr* exprAcolonB = new ScpExprListExpr( *b, *b );
			exprAcolonB->addExpressin( exprPropName, 1 );
			exprAcolonB->addExpressin( exprAsgmnt, 1 );
			exprObjLtrl->addExpressin( exprAcolonB, 1 );
			exprPropName = exprAsgmnt = 0;
			b = inp.out3.endded3;
		}
		if( b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSuccess=0
		}
		// either of two here: (1) brace close or (2) comma.
		if( b->tpe == SCP_ET_Op && b->tkn2 == "," ){
			// check if comma is followed by a brace-close character, allow empty
			// comma on obj-literal termination.
			ScpTCITR d = b;
			if( ++d != inp.tokenend && d->tpe == SCP_ET_Op && d->tkn2 == "\x7D" ){ // 0x7D = brace close character.
				b = d;
				bSuccess = 1;
				break;
			}
			// path here continues to the next property.
		}else if( b->tpe == SCP_ET_Op && b->tkn2 == "\x7D" ){ // 0x7D = brace close character.
			bSuccess = 1;
			break;
		}else{
			inp.errClear( ScpErr( b->tkn, SCP_EE_ObjLtrlNoCommaOrBrCl,
					"Expected comma or brace close here." ) );
			break; //bSuccess=0
		}
	}
	if( !bSuccess ){
		delete exprObjLtrl;
		exprObjLtrl = 0;
		if( exprPropName ){
			delete exprPropName;
			exprPropName = 0;
		}
		if( exprAsgmnt ){
			delete exprAsgmnt;
			exprAsgmnt = 0;
		}
		assert( inp.out3.err.errpos.ptr );
		// Note: error structure already assigned before any 'break' from above.
		return 0;
	}
	inp.out3.expr2   = exprObjLtrl;
	inp.out3.endded3 = ++b;
	return 1;
}

bool ScpTryVarStmt::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Wrd || a->tkn2 != "var" )
		return 1;
	ScpTCITR b = a; // Identifier : AssignmentExpression
	if( ++b == inp.tokenend ){
		inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpParse in2( inp, b );
	if( !scpTryIdentifierExpr.tryy(in2) )
		return 0;
	if( !inp.out3.expr2 ){
		inp.errClear( ScpErr( b->tkn, SCP_EE_VarStmtNoIdentifier, "No identifier follows 'var' keyword." ) );
		return 0;
	}
	ScpVarStatement* exprVar = new ScpVarStatement( *a, *a ); //ScpExprListExpr*
	exprVar->addExpressin( inp.extractExpr(), 1 );
	bool bSucc = 0;
	do{
		b = inp.out3.endded3;
		if( b == inp.tokenend || b->tpe != SCP_ET_Op || b->tkn2 != "=" ){
			bSucc = 1;
			break;
		}
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
			break; //bSucc=0
		}
		ScpParse in3( inp, b );
		if( !scpTryAsgmntExpr.tryy(in3) )
			break; //bSucc=0
		if( inp.out3.expr2 ){
			exprVar->addExpressin( inp.extractExpr(), 1 );
			b = inp.out3.endded3;
		}
		bSucc = 1;
	}while(0);
	if(!bSucc){
		delete exprVar;
		return 0;
	}
	inp.out3.expr2   = exprVar;
	inp.out3.endded3 = b;
	return 1;
}
ScpTryFIterationStmt::ScpTryFIterationStmt( bool bIsTheIfStmtOnly )
	: IsTheIfStmtOnly( bIsTheIfStmtOnly )
{
}
bool ScpTryFIterationStmt::tryy( const ScpParse& inp )
{
	int nTripleOrNot = 3; bool bIsIFStatement = 0;
	const ScpTCITR a = inp.tokenbgn;
	if( a->tpe == SCP_ET_Wrd && a->tkn2 == "for" && !IsTheIfStmtOnly ){
		bIsIFStatement = 0;
	}else if( a->tpe == SCP_ET_Wrd && a->tkn2 == "if" ){
		bIsIFStatement = 1;
		nTripleOrNot = 1;
	}else
		return 1;

	ScpTCITR b = a;
	if( ++b == inp.tokenend ){
		inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	const ScpTCITR irParen = b;
	if( b->tpe != SCP_ET_Op || b->tkn2 != "\x28" ){ //0x28: paren open.
		inp.errClear( ScpErr( b->tkn, SCP_EE_ForStntSyntaxError,
			"No paren follows 'for' keyword." ) );
		return 0;
	}
	if( ++b == inp.tokenend ){
		inp.errClear( ScpErr( irParen->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpExtraPtr<ScpExprListExpr> expr1to3List( new ScpExprListExpr( *b, *b ) );
	if(bIsIFStatement){
		expr1to3List.getPtr()->addExpressin( new ScpCtrlFlowStmt(SCP_ECF_EmptyTrue,*b), 1 );
	}
	// for each one of the 3 expressions inside the parens.
	for( int i=0; i < nTripleOrNot; i++ ){
		assert( !inp.out3.expr2 );
		if( i == (nTripleOrNot-1) && b->tpe == SCP_ET_Op && b->tkn2 == "\x29" && !bIsIFStatement ){ // 0x29: paren close.
			inp.out3.expr2 = new ScpCtrlFlowStmt( SCP_ECF_EmptyTrue, *b );
		}else if( i < (nTripleOrNot-1) && b->tpe == SCP_ET_Op && b->tkn2 == ";" && !bIsIFStatement ){
			inp.out3.expr2 = new ScpCtrlFlowStmt( SCP_ECF_EmptyTrue, *b );
		}else{
			ScpParse in2( inp, b, inp.tokenend, inp.out3 );
			if( !scpTryExpressionStmt.tryy( in2 ) )
				return 0;
			if( !inp.out3.expr2 ){
				inp.errClear( ScpErr( b->tkn, SCP_EE_ForStntExpr1to3Bad,
					((*ScpStr("Unknown expression #%a (of %a) inside for-statement.").a(i+1).a(nTripleOrNot)).c_str()) ) );
				return 0;
			}
			{
				ScpTCITR c = inp.out3.endded3;
				if( c == inp.tokenend ){
					inp.errClear( ScpErr( irParen->tkn, SCP_EE_EofOnParse ) );
					return 0;
				}
				if( c != b ){
					ScpTCITR d = c;
					--d;
					if( d->tpe == SCP_ET_Op && d->tkn2 == ";" )
						c = d;
				}
				b = c;
			}
		}
		expr1to3List.getPtr()->addExpressin( inp.extractExpr(), 1 );
		if( i == nTripleOrNot-1 ){
			if( b->tpe != SCP_ET_Op || b->tkn2 != "\x29" ){ // 0x29: paren close.
				inp.errClear( ScpErr( b->tkn, SCP_EE_ForStntSyntaxError,
					(*ScpStr("No closing paren follows expression #%a inside for-statement.").a(i+1)).c_str() ) );
				return 0;
			}
		}else{
			if( b->tpe != SCP_ET_Op || b->tkn2 != ";" ){
				inp.errClear( ScpErr( b->tkn, SCP_EE_ForStntSyntaxError,
					((*ScpStr("No semicolon follows expression #%a (of %a) inside for-statement.").a(i+1).a(nTripleOrNot)).c_str()) ) );
				return 0;
			}
		}
		if( ++b == inp.tokenend ){
			inp.errClear( ScpErr( irParen->tkn, SCP_EE_EofOnParse ) );
			return 0;
		}
	}
	ScpExtraPtr<ScpIExpr> exprBody2( 0 );   //ScpFIterationBody*,ScpExprListExpr*
	ScpTCITR c = inp.tokenend;
	{
		ScpParse in3( inp, b, inp.tokenend, inp.out3 );
		if( !scpTryBlockStmt.tryy(in3) ) //ScpTryBlockStmt*
			return 0;
		if( !inp.out3.expr2 ){
			inp.errClear( ScpErr( b->tkn, SCP_EE_ForStntSyntaxError,
				"No block statement follows parens that follow 'for' keyword.") );
			return 0;
		}
		c = in3.out3.endded3;
		ScpFIterationBody* exprBody3 = dynamic_cast<ScpFIterationBody*>( inp.extractExpr() );
		assert( exprBody3 );
		exprBody2.setPtr( exprBody3 );
	}
	assert( exprBody2.getPtr() );
	inp.out3.endded3 = c;
	ScpExtraPtr<ScpIExpr> exprTheElse( 0 );
	if( bIsIFStatement ){
		ScpParse in2( inp, c, inp.tokenend, inp.out3 );
		if( !scpTryTheElseStmt.tryy(in2) ) //ScpTryTheElseStmt*
			return 0;
		if( in2.out3.expr2 ){
			exprTheElse.setPtr( in2.extractExpr() );
			c = inp.out3.endded3;
		}
	}
	ScpFIterationStatement* expr = new ScpFIterationStatement(
							expr1to3List.addRef().getPtr(),
							exprBody2.addRef().getPtr(),
							*a, *(--c),
							( bIsIFStatement ? SCP_E4_IfStatement : 0 ) );
	if( exprTheElse.getPtr() ){
		expr->setTheElseExpr( exprTheElse.addRef().getPtr() );
	}
	inp.out3.expr2 = expr;
	return 1;
}
//	11 Expressions
//		Primary Expressions
//		Left-Hand-Side Expressions
//		Postfix Expressions
//		Unary Operators
//		Multiplicative Operators
//		Additive Operators
//		Bitwise Shift Operators
//		Relational Operators
//		Equality Operators
//		Binary Bitwise Operators
//		Binary Logical Operators
//		Conditional Operator ( ? : )
//		Assignment Operators
//		Comma Operator ( , )
bool ScpTryExpressionStmt::tryy( const ScpParse& inp )
{
	// Expressions are "trying" each other recursivelly in the
	// expression chain, thus only top one of them should be
	// "tried" here.
	if( !scpTryAsgmntExpr.tryy(inp) ) // ScpTryAsgmntExpr*
		return 0;
	return 1;
}
ScpTryStatementStmt::ScpTryStatementStmt( ScpTryProgramParse* program2 )
{
	assert( program2 );
	ScpTryGroupingExpr* tge = program2->getTheTryGroupingExpr();
	assert( tge );
	Parsers5 = new ScpTry1stOkExpr;
	Parsers5->addTryParser( new ScpTryFIterationStmt, 1 );
	Parsers5->addTryParser( new ScpTryVarStmt, 1 );
	Parsers5->addTryParser( new ScpTryCtrlFlowStmt, 1 );
	Parsers5->addTryParser( tge, 0 );
}
ScpTryStatementStmt::~ScpTryStatementStmt()
{
	assert(Parsers5);
	delete Parsers5;
	Parsers5 = 0;
}
bool ScpTryStatementStmt::tryy( const ScpParse& inp )
{
	if( !Parsers5->tryy(inp) )
		return 0;
	return 1;
}
ScpTryStmtListStmt::ScpTryStmtListStmt( ScpTryProgramParse* program2 )
{
	TryStatementStmt = new ScpTryStatementStmt( program2 );
}
ScpTryStmtListStmt::~ScpTryStmtListStmt()
{
	assert(TryStatementStmt);
	delete TryStatementStmt;
	TryStatementStmt = 0;
}
bool ScpTryStmtListStmt::tryy( const ScpParse& inp )
{
	assert( !inp.out3.expr2 );
	ScpExtraPtr<ScpExprListExpr> exprs2( new ScpExprListExpr( *inp.tokenbgn, *inp.tokenbgn ) );
	ScpTCITR a;
	for( a = inp.tokenbgn; a != inp.tokenend; ){
		{
			ScpParse in2( inp, a, inp.tokenend, inp.out3 );
			if( !TryStatementStmt->tryy(in2) ) // ScpTryStatementStmt*
				return 0;
			assert( inp.out3.err.tpe3 == SCP_EE_Unknown );
			if( !inp.out3.expr2 ){ // if no expression was recognized at token 'a'.
				//printf("%d SCP_EE_TokenSeqUnknown\n", SCP_EE_TokenSeqUnknown );
				inp.out3.err.tpe3   = SCP_EE_TokenSeqUnknown;
				inp.out3.err.msg2   = "Encountered unknown token sequence.";
				inp.out3.err.errpos = a->tkn;
				return 0;
			}
			assert( a != inp.out3.endded3 );
			assert( inp.out3.expr2 );
			inp.out3.expr2->setOpnToken( *a );
		}
		a = inp.out3.endded3;
		exprs2.getPtr()->addExpressin( inp.out3.expr2, 1 );
		inp.out3.expr2 = 0;
	}
	inp.out3.endded3 = a;
	inp.out3.expr2 = exprs2.addRef().getPtr(); //ScpExprListExpr*
	return 1;
}
bool ScpTryBlockStmt::tryy( const ScpParse& inp )
{
	const ScpTCITR a = inp.tokenbgn;
	if( a->tpe != SCP_ET_Op || a->tkn2 != "\x7B" ) //0x7B: brace open, 0x7D: brace close
		return 1;
	ScpTCITR b = a, itrClose;
	++b;
	// scan recursivelly until brace close token match.
	itrClose = ScpTryGroupingExpr::scanForBraceLv1Rcv( b, inp.tokenend, "{","}" );
	if( itrClose == inp.tokenend ){
		inp.errClear( ScpErr( a->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpParse in2( inp, b, itrClose, inp.out3 );
	if( !inp.prgrm->getTheTryStmtListStmt()->tryy( in2 ) ) // ScpTryStmtListStmt
		return 0;
	assert( itrClose == in2.out3.endded3 );
	assert( inp.out3.expr2 );
	//
	ScpFIterationBody* expr = 0;
	{
		ScpExprListExpr* exprBody4 = dynamic_cast<ScpExprListExpr*>( in2.extractExpr() );
		assert( exprBody4 );
		expr = new ScpFIterationBody( *b, *itrClose );
		std::swap(
			*(exprBody4->getInnerExpressionsIfAny()),
			*(expr->getInnerExpressionsIfAny()) );
		delete exprBody4;
	}
	inp.out3.endded3 = ++itrClose;
	inp.out3.expr2   = expr;  //exprs3.addRef().getPtr();
	return 1;
}
bool ScpTryCtrlFlowStmt::tryy( const ScpParse& inp )
{
	ScpTCITR a = inp.tokenbgn;
	if( a->tkn2 == "break" ){
		//SCP_E2_CtrlFlowBreak;
		//ScpCtrlFlowStmt::getCtrlFlowTypeIfAny()
		inp.out3.expr2   = new ScpCtrlFlowStmt( SCP_ECF_Break, *a );
		inp.out3.endded3 = ++a;
		return 1;
	}else if( a->tkn2 == "continue" ){
		inp.out3.expr2   = new ScpCtrlFlowStmt( SCP_ECF_Continue, *a );
		inp.out3.endded3 = ++a;
		return 1;
	}else if( a->tkn2 == "return" ){
		inp.out3.expr2   = new ScpCtrlFlowStmt( SCP_ECF_Return, *a );
		inp.out3.endded3 = ++a;
		return 1;
	}
	return 1;
}
bool ScpTryTheElseStmt::tryy( const ScpParse& inp )
{
	if( inp.tokenbgn->tpe != SCP_ET_Wrd || inp.tokenbgn->tkn2 != "else" ){
		return 1;
	}
	ScpTCITR b = inp.tokenbgn;
	if( ++b == inp.tokenend ){
		inp.errClear( ScpErr( inp.tokenbgn->tkn, SCP_EE_EofOnParse ) );
		return 0;
	}
	ScpParse in2( inp, b, inp.tokenend, inp.out3 );
	if( !scpTryBlockStmt.tryy(in2) ){ //ScpTryBlockStmt*
		return 0;
	}
	//ScpExprListExpr*

	if( !in2.out3.expr2 ){
		if( !scpTryTheIfStmt.tryy(in2) ) //ScpTryFIterationStmt*
			return 0;
	}
	if( !inp.out3.expr2 ){
		inp.errClear( ScpErr( inp.tokenbgn->tkn, SCP_EE_TheElseStmtSyntaxError,
			"No block statement follows the 'else' keyword." ) );
		return 0;
	}
	inp.out3.expr2 = in2.extractExpr();  //inp.out3.endded3 = ++b;
	return 1;
}









