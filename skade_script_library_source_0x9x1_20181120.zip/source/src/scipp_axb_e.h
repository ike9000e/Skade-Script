
#ifndef _SCIPP_AXB_E_H_
#define _SCIPP_AXB_E_H_
#include "scipp_expr.h"
#include <vector>

class ScpIdentifierExpr : public ScpIExpr {
public:
	;                     ScpIdentifierExpr( const ScpToken& tkn );
	virtual               ~ScpIdentifierExpr() {}
	virtual bool          eval6( const ScpEval& in );
	virtual std::string   strPrint2( const ScpPrnt& inp )const;
};

class ScpAxBExpr : public ScpIExpr {
public:
	;                   ScpAxBExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr );
	virtual             ~ScpAxBExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	bool evalCompoundOp( const ScpEval& evl, ScpValue* lval2, ScpValue* rval2, const char* op2 )const;
private:
	ScpIExpr* LeftExpr, *RightExpr;
	ScpToken* OpTkn;
};
class ScpAssignmentExpr : public ScpAxBExpr {
public:
	ScpAssignmentExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr );
	virtual bool eval6( const ScpEval& inp );
};

class ScpGroupingExpr : public ScpIExpr {
public:
	;                   ScpGroupingExpr( ScpIExpr* innerExpr, const ScpToken& opn2, const ScpToken& close2 );
	virtual             ~ScpGroupingExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	ScpIExpr* InnerExpr;
};
/// Holds expressions as an internal list.
/// Used for example to hold expressions of argument list.
class ScpExprListExpr : public ScpIExpr {
public:
	;                   ScpExprListExpr( const ScpToken& opn2, const ScpToken& close2 );
	virtual             ~ScpExprListExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
	void                addExpressin( ScpIExpr* exprr, bool bOwnAndDele );
	int                 getExprCount()const {return (int)ArgList.size();}
	ScpIExpr*           getExprAt( int idx );
	virtual const char* getExprListName()const {return "ARGs";}
	virtual std::vector<ScpIExpr*>* getInnerExpressionsIfAny() {return &ArgList;}
private:
	std::vector<ScpIExpr*> ArgList;
};
class ScpCallExpr : public ScpIExpr {
public:
	;                   ScpCallExpr( const ScpToken& opn2, ScpIExpr* LeftExpr_, ScpExprListExpr* ArgsExpr_ );
	virtual             ~ScpCallExpr();
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	ScpIExpr* LeftExpr;
	ScpExprListExpr* ArgsExpr;
};

class ScpStrLiteralExpr : public ScpIExpr {
public:
	;                   ScpStrLiteralExpr( const ScpToken& tkn_ );
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	std::string pseudoevalQuotedStr( const char* inp, int len );
};

class ScpNumericLiteralExpr : public ScpIExpr {
public:
	;                   ScpNumericLiteralExpr( const ScpToken& tkn_ );
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
};

class ScpObjLiteralExpr : public ScpExprListExpr {
public:
	;                   ScpObjLiteralExpr( const ScpToken& opn2, const ScpToken& close2 );
	virtual bool        eval6( const ScpEval& inp );
	virtual const char* getExprListName()const {return "Object-Literal";}
};

class ScpVarStatement : public ScpExprListExpr {
public:
	;                   ScpVarStatement( const ScpToken& opn2, const ScpToken& close2 );
	virtual bool        eval6( const ScpEval& inp );
	virtual const char* getExprListName()const {return "Var-Statement";}
};

/// Flags used by ScpFIterationStatement.
enum{
    SCP_E4_IfStatement = 0x1,
};
struct ScpFIterationStatement : public ScpIExpr
{
	;                   ScpFIterationStatement( ScpExprListExpr* innerExprX3, ScpIExpr* blockExpr, const ScpToken& opn2, const ScpToken& close2, int flags2 );
	virtual             ~ScpFIterationStatement();
	virtual bool        eval6( const ScpEval& inp );
	void                setTheElseExpr( ScpIExpr* exprElse );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
private:
	ScpExprListExpr* InnerExprX3;
	ScpIExpr*        BlockExpr; //ScpExprListExpr*,ScpFIterationBody*
	ScpIExpr*        ExprElse;
	int              Flags2; //eg. SCP_E4_IfStatement
};
struct ScpFIterationBody : public ScpExprListExpr
{
	;                   ScpFIterationBody( const ScpToken& opn2, const ScpToken& close2 );
	virtual             ~ScpFIterationBody() {}
	virtual bool        eval6( const ScpEval& inp );
};
struct ScpCtrlFlowStmt : public ScpIExpr
{
	;                   ScpCtrlFlowStmt( int eCtrlFlType_, const ScpToken& tkOpn );
	virtual bool        eval6( const ScpEval& inp );
	virtual std::string strPrint2( const ScpPrnt& inp )const;
	virtual int         getCtrlFlowTypeIfAny()const {return CtrlFlType;}
private:
	int CtrlFlType;
};
struct ScpBuiltinFuncIdentifierExpr : public ScpIdentifierExpr
{
	;                   ScpBuiltinFuncIdentifierExpr( const ScpToken& tkn );
	virtual bool        eval6( const ScpEval& inp );
};

#endif // _SCIPP_AXB_E_H_
