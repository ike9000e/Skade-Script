
#ifndef _SCIPP_AXB_P_H_
#define _SCIPP_AXB_P_H_
#include "scipp_tryparser.h"

class ScpTryProgramParse;

/*
	Expression -> AssignmentExpression->...-> BitwiseANDExpression
	->...-> EqualityExpression->...-> AdditiveExpression
	-> MultiplicativeExpression-> UnaryExpression-> PostfixExpression
	-> LeftHandSideExpression->...
	-> CallExpression -> MemberExpression -> PrimaryExpression

	CallExpression

	MultiplicativeExpression : See section 11.5
		UnaryExpression
		MultiplicativeExpression * UnaryExpression
		MultiplicativeExpression / UnaryExpression
		MultiplicativeExpression % UnaryExpression

	Note: in simplified parsing, UnaryExpression is reduced to a PrimaryExpression,
	_     whitch in turn, in even more simplier parsing, can be
	_     just identifier and literals.
*/
class ScpTryAxBExpr : public ScpITryParser {
public:
	;                       ScpTryAxBExpr( const char* op1="*", const char* op2=0, const char* op3=0, const char* op4=0 );
	virtual                 ~ScpTryAxBExpr() {}
	virtual bool            tryy( const ScpParse& inp );
	void addOperator( const char* op2 );
private:
	virtual ScpITryParser*  getLeftAxBExprParser();
private:
	std::vector<std::string> Ops;
};
/*
	AdditiveExpression : See section 11.6
		MultiplicativeExpression
		AdditiveExpression + MultiplicativeExpression
		AdditiveExpression - MultiplicativeExpression
*/
class ScpTryAdditiveExpr : public ScpTryAxBExpr {
public:
	ScpTryAdditiveExpr();
private:
	virtual ScpITryParser* getLeftAxBExprParser();
};
/*
	PrimaryExpression : See section 11.1
		this
		Identifier
		Literal
		ArrayLiteral
		ObjectLiteral
		( Expression )
*/
class ScpTryPrimaryExpr : public ScpITryParser {
public:
	virtual ~ScpTryPrimaryExpr() {}
	virtual bool tryy( const ScpParse& inp );
};
class ScpTryIdentifierExpr : public ScpITryParser
{
public:
	virtual bool tryy( const ScpParse& inp );
};
/*
	AssignmentExpression : See section 11.13
		ConditionalExpression
		LeftHandSideExpression AssignmentOperator AssignmentExpression
*/
class ScpTryAsgmntExpr : public ScpTryAxBExpr
{
public:
	ScpTryAsgmntExpr();
	virtual ScpITryParser* getLeftAxBExprParser();
};
/*
	Grouping expression using parentheses.
	The '( Expression )' expression.

	11.1.6 The Grouping Operator
	The production PrimaryExpression : ( Expression ) is evaluated as follows:
		1. Evaluate Expression. This may be of type Reference.
		2. Return Result(1).

	ref: CTryGroupingOpExpr, ETK_PN_PARENTHESES_OPEN, jsc_GlobTryTheExpr
*/
class ScpTryGroupingExpr : public ScpITryParser {
public:
	ScpTryGroupingExpr( const ScpTryProgramParse* program2 );
	virtual bool tryy( const ScpParse& inp );
	virtual ScpITryParser* getInnerExprParser();
	static ScpTCITR scanForBraceLv1Rcv( ScpTCITR bgn, const ScpTCITR& endd, const char* tknOpen, const char* tknClose );
private:
	ScpTCITR LastTokenAt;
};

/*
	CallExpression :
		MemberExpression Arguments
		CallExpression Arguments
		CallExpression [ Expression ]
		CallExpression . Identifier

	Arguments :
		( )
		( ArgumentList )

	ArgumentList :
		AssignmentExpression
		ArgumentList , AssignmentExpression
*/
class ScpTryCallExpr : public ScpITryParser {
public:
	ScpTryCallExpr() {}
	virtual bool tryy( const ScpParse& inp );
};
class ScpTryArgumentsExpr : public ScpITryParser {
public:
	ScpTryArgumentsExpr() {}
	virtual bool tryy( const ScpParse& inp );
};

/**
	Str literal as an expression.
	Inherriting from expr, rather than own class, as it seems easy
	to implement. Evaluating would parse str-piece for escape character sequences
	and return escaped string. Other functionality is possible to add here,
	like shell-style variables inside dbl-quoted strings or use of raw strings.
*/
class ScpTryStringLiteral : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};

class ScpTryNumericLiteral : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};

/*
	list of elements:
		PropertyName : AssignmentExpression
*/
class ScpTryObjectLiteral : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};
/*
	PropertyName :
		IdentifierName
		StringLiteral
		NumericLiteral
*/
class ScpTryPropertyName : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};


class ScpTryVarStmt : public ScpITryParser {
public:
	virtual bool tryy( const ScpParse& inp );
};

/**
	Iteration statement, ie. for-statement.

	\verbatim
		IterationStatement :
			for ( ExpressionNoInopt ; Expressionopt ; Expressionopt ) Statement
	\endverbatim
*/
struct ScpTryFIterationStmt : public ScpITryParser
{
	ScpTryFIterationStmt( bool bIsTheIfStmtOnly = 0 );
	virtual bool tryy( const ScpParse& inp );
private:
	bool IsTheIfStmtOnly;
};
/*
	11 Expressions

		Primary Expressions
		Left-Hand-Side Expressions
		Postfix Expressions
		Unary Operators
		Multiplicative Operators
		Additive Operators
		Bitwise Shift Operators
		Relational Operators
		Equality Operators
		Binary Bitwise Operators
		Binary Logical Operators
		Conditional Operator ( ? : )
		Assignment Operators
		Comma Operator ( , )

	ExpressionStatement :
		[ lookahead ∉ { \\x7B, function } ] Expression ;
*/
struct ScpTryExpressionStmt : public ScpITryParser {
	virtual bool tryy( const ScpParse& inp );
};

/**
	Block statement, things within braces ("{...}").

	\verbatim
		Block :
			{ StatementList-opt }

		StatementList :
			Statement
			StatementList Statement
	\endverbatim
*/
struct ScpTryBlockStmt : public ScpITryParser {
	virtual bool tryy( const ScpParse& inp );
};
/*
	Statement :
		Block
		VariableStatement
		EmptyStatement
		ExpressionStatement
		IfStatement
		IterationStatement
		ContinueStatement
		BreakStatement
		ReturnStatement
		WithStatement
		LabelledStatement
		SwitchStatement
		ThrowStatement
		TryStatement
		DebuggerStatement
*/
struct ScpTryStatementStmt : public ScpITryParser {
	;            ScpTryStatementStmt( ScpTryProgramParse* program2 );
	virtual      ~ScpTryStatementStmt();
	virtual bool tryy( const ScpParse& inp );
private:
	ScpTry1stOkExpr* Parsers5;
};
/**
	Try Statement List Statement.

	\verbatim
		Program :
			SourceElements-opt
		SourceElements :
			SourceElement
			SourceElements SourceElement
		SourceElement :
			Statement
			FunctionDeclaration
	\endverbatim
*/
struct ScpTryStmtListStmt : public ScpITryParser {
	;                        ScpTryStmtListStmt( ScpTryProgramParse* program2 );
	virtual                  ~ScpTryStmtListStmt();
	virtual bool             tryy( const ScpParse& inp );
private:
	ScpTryStatementStmt*     TryStatementStmt;
};

/// Control flow statements like "break", "continue" or "return".
struct ScpTryCtrlFlowStmt : public ScpITryParser {
	virtual bool tryy( const ScpParse& inp );
};
/**
	The ELSE statement or the ELSE-IF statement.
*/
struct ScpTryTheElseStmt : public ScpITryParser
{
	virtual bool tryy( const ScpParse& inp );
};

struct ScpTryTheIfStmt : public ScpTryFIterationStmt
{
	ScpTryTheIfStmt() : ScpTryFIterationStmt(1) {}

	virtual bool tryy( const ScpParse& inp );
};


#endif // _SCIPP_AXB_P_H_
