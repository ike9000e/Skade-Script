
#include "scipp_axb_e.h"
#include <assert.h>
//#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
#include <cstring>
#include <cstdlib> //std::strtoul()
#include "scipp_tryparser.h"
#include "scipp_value.h"
#include "../inc/scipp/scipp_script.h"

ScpIdentifierExpr::ScpIdentifierExpr( const ScpToken& tkn )
	: ScpIExpr("ScpIdentifierExpr",tkn)
{
}
std::string ScpIdentifierExpr::strPrint2( const ScpPrnt& inp )const
{
	std::string z;
	z += *ScpStr("%a""'%a' (identifier)")
			.a( inp.tbs )
			.a( getOpnToken().tkn2.c_str() );
	return z;
}
bool ScpIdentifierExpr::eval6( const ScpEval& inp )
{
	const ScpToken& tke = getOpnToken();
	assert( !tke.tkn2.empty() );
	//ScpScope*
	std::string vname = tke.tkn2;
	ScpGetScopeVar sgv = { vname.c_str(), tke, inp, };
	if( !inp.scope2->getScopeVariable( sgv ) )
		return 0;
	assert( inp.out4.value2 );
	//
	if( inp.out4.value2->getValueType() == SCP_E2_HostObject ){
		ScpToken* tknn = inp.out4.value2->getTokenIfAny();
		assert(tknn);
		ScpSp& sptkn = tknn->tkn;
		sptkn = tke.tkn;
	}
	inp.out4.value2->grabVal();
	return 1;
}
ScpAxBExpr::
ScpAxBExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr )
	: ScpIExpr( "ScpAxBExpr", leftexpr->getOpnToken() )
	, LeftExpr(leftexpr), RightExpr(rightexpr)
	, OpTkn(new ScpToken(operToken))
{
	assert( LeftExpr && RightExpr );
}
ScpAxBExpr::~ScpAxBExpr()
{
	assert( LeftExpr && RightExpr && OpTkn );
	delete LeftExpr;
	delete RightExpr;
	delete OpTkn;
}
std::string ScpAxBExpr::strPrint2( const ScpPrnt& inp )const
{
	ScpPrnt in2( inp );
	in2.addTabs(1);
	std::string z;
	z += *ScpStr("%a""AxB: '%a' L:[\n%a\n%a] '%a' R:[\n%a\n%a]")
			.a( inp.tbs )
			.a( OpTkn->tkn2.c_str() )
			.a( LeftExpr->strPrint2( in2 ) )
			.a( inp.tbs )
			.a( OpTkn->tkn2.c_str() )
			.a( RightExpr->strPrint2( in2 ) )
			.a( inp.tbs );
	return z;
}
ScpGroupingExpr::
ScpGroupingExpr( ScpIExpr* innerExpr, const ScpToken& opn2, const ScpToken& close2 )
	: ScpIExpr( "ScpGroupingExpr", opn2 ), InnerExpr(innerExpr)
{
	setEnclosingTokens( opn2, close2 );
}
ScpGroupingExpr::~ScpGroupingExpr()
{
	delete InnerExpr;
}
std::string ScpGroupingExpr::strPrint2( const ScpPrnt& inp )const
{
	ScpPrnt in2( inp );
	in2.addTabs(1);
	std::string z;
	z += *ScpStr("%a""GRP: '%a%a' [\n%a\n%a]")
			.a( inp.tbs )
			.a( getEnclosingTokens(0)->tkn2.c_str() )
			.a( getEnclosingTokens(1)->tkn2.c_str() )
			.a( InnerExpr->strPrint2( in2 ) )
			.a( inp.tbs );
	return z;
}

bool ScpGroupingExpr::eval6( const ScpEval& inp )
{
	return InnerExpr->eval6(inp);
}
bool ScpAxBExpr::eval6( const ScpEval& inp )
{
	assert( LeftExpr && RightExpr );
	ScpValAutoPtr rval, lval;
	//if( dynamic_cast<ScpObjLiteralExpr*>( rval() ) ){
	//}
	if( !RightExpr->eval6( inp ) )
		return 0;
	rval.setPointer( inp.extractValue(), 0 );
	assert( rval() );
	if( !LeftExpr->eval6( inp ) )
		return 0;
	lval.setPointer( inp.extractValue(), 0 );
	assert( lval() );
	//printf("oper [%s]%s[%s]\n",
	//		lval()->stdToString().c_str(), OpTkn->tkn2.c_str(),
	//		rval()->stdToString().c_str() );
	ScpSpeOper sop = { inp, rval(), &inp.out4.value2, };
	if( OpTkn->tkn2 == "*" ){
		if( !lval()->evalOperatorMul( sop ) )
			return 0;
	}else if( OpTkn->tkn2 == "+" ){
		if( !lval()->evalOperatorAdd( sop ) )
			return 0;
	}else if( OpTkn->tkn2 == "=" ){
		//bool bObLtrl = !!dynamic_cast<ScpObjLiteralExpr*>( rval() );
		//if( bObLtrl ){
		//	sop.sev.out4.lvalRef2 = lval();
		//}
		if( !lval()->evalOperatorAssign( sop ) )
			return 0;
		if( !inp.out4.value2 )
			inp.out4.value2 = lval();
		//if( bObLtrl ){
		//}
	}else if( OpTkn->tkn2 == "-" ){
		if( !lval()->evalOperatorSub( sop ) )
			return 0;
	}else if( OpTkn->tkn2 == "/" ){
		if( !lval()->evalOperatorDiv( sop ) )
			return 0;
	}else if( OpTkn->tkn2 == "%" ){
		if( !lval()->evalOperatorPercent( sop ) )
			return 0;
	}else if( ScpFindByStrcmpInArgv( OpTkn->tkn2.c_str(), ScpSp::CompoundOpers, -1 ) ){
		if( !evalCompoundOp( inp, lval(), rval(), OpTkn->tkn2.c_str() ) )
			return 0;
	}else{
		inp.errClear2( ScpErr( OpTkn->tkn, SCP_EE_UnexpectedOper,"Unexpected operator to evaluate." ) );
		return 0;
	}
	if( inp.out4.value2 == lval() )
		lval.setPointer(0,0);
	assert( inp.out4.value2 != rval() );
	assert( inp.out4.value2 ); // sop.sev === inp
	return 1;
}
ScpAssignmentExpr::
ScpAssignmentExpr( ScpIExpr* leftexpr, const ScpToken& operToken, ScpIExpr* rightexpr )
	: ScpAxBExpr(leftexpr,operToken,rightexpr)
{
}
bool ScpAssignmentExpr::eval6( const ScpEval& inp )
{
	return ScpAxBExpr::eval6(inp);
}
/**
	Constructor.
	\param argvOwn - list of expressions that the object will take owneship of,
	                 ie. they will be deleted on this object destruction.
*/
ScpExprListExpr::
ScpExprListExpr( const ScpToken& opn2, const ScpToken& close2 )
	: ScpIExpr( "ScpExprListExpr", opn2 )
{
	setEnclosingTokens( opn2, close2 );
}
void ScpExprListExpr::addExpressin( ScpIExpr* expr, bool bOwnAndDel )
{
	assert(bOwnAndDel);
	ArgList.push_back( expr );
}
ScpExprListExpr::~ScpExprListExpr()
{
	std::vector<ScpIExpr*>::iterator a;
	for( a = ArgList.begin(); a != ArgList.end(); ++a ){
		delete *a;
	}
	ArgList.clear();
}
ScpCallExpr::
ScpCallExpr( const ScpToken& opn2, ScpIExpr* LeftExpr_, ScpExprListExpr* ArgsExpr_ )
	: ScpIExpr( "ScpCallExpr", opn2 ), LeftExpr(LeftExpr_), ArgsExpr(ArgsExpr_)
{
}
ScpCallExpr::~ScpCallExpr()
{
	delete LeftExpr;
	delete ArgsExpr;
}
std::string ScpCallExpr::strPrint2( const ScpPrnt& inp )const
{
	ScpPrnt in2( inp );
	in2.addTabs(1);
	std::string z;
	z += *ScpStr("%a""CAL: L:[\n%a\n%a] R:[\n%a\n%a]")
			.a( inp.tbs )
			.a( LeftExpr->strPrint2( in2 ) )
			.a( inp.tbs )
			.a( ArgsExpr->strPrint2( in2 ) )
			.a( inp.tbs );
	return z;
}
std::string ScpExprListExpr::strPrint2( const ScpPrnt& inp )const
{
	ScpPrnt in2( inp );
	in2.addTabs(1);
	std::string z;
	std::vector<ScpIExpr*>::const_iterator a; int i;
	z += *ScpStr("%a""%a-%a: [")
			.a( inp.tbs )
			.a( getExprListName() ) //"ARGs"
			.a( (int)ArgList.size() );
	for( i=0, a = ArgList.begin(); a != ArgList.end(); ++a, i++ ){
		z += *ScpStr(" ""arg-%a: [\n%a\n%a]")
				.a( i+1 )
				.a( (**a).strPrint2(in2) )
				.a( inp.tbs );
	}
	z += "]";
	return z;
}
bool ScpExprListExpr::eval6( const ScpEval& inp )
{
	assert(!"ScpExprListExpr ment to be never evalueated.");
	return 0;
}
ScpIExpr* ScpExprListExpr::getExprAt( int idx )
{
	assert( idx < (int)ArgList.size() );
	return ArgList[idx];
}
bool ScpCallExpr::eval6( const ScpEval& inp )
{
	assert( LeftExpr && ArgsExpr );
	if( !LeftExpr->eval6( inp ) )
		return 0;
	ScpValue* val2 = inp.extractValue();
	assert( val2 );
	ScpValListVal argvals3( ArgsExpr->getOpnToken() );
	argvals3.addVal( val2, 1 );
	{
		int i = ArgsExpr->getExprCount() - 1;
		for(; i >= 0; i-- ){
			ScpIExpr* expr = ArgsExpr->getExprAt(i);
			ScpEvalOu ou2( inp.out4.err4 );
			ScpEval in2( inp, ou2 );
			if( !expr->eval6( in2 ) )
				return 0;
			ScpValue* val = in2.extractValue();
			assert( val );
			argvals3.addVal( val, 1 );
		}
	}
//	int iErrIs = -1, nErr = SCP_EE_Unknown;
//	ScpEvalCallAndArgs evca = { &iErrIs, &nErr, &inp.out4.value2, LeftExpr->getOpnToken(), argvals3, };
//	if( !inp.scope2->evalHostFunctionCall( evca ) ){
//		assert( !inp.out4.value2 );
//		inp.errClear2( ScpErr( LeftExpr->getOpnToken().tkn, nErr ) );
//		return 0;
//	}
	{
		assert( argvals3.getValCount() > 0 );
		int numargs = argvals3.getValCount() - 1;
		int k = numargs - 1;
		std::vector<ScpValue*> argvals( numargs, (ScpValue*)0 );
		for( int i=0; i < numargs; i++, k-- ){
			argvals[k] = argvals3.getValAt( i+1 );
		}
		ScpSpeCall ssc = { inp, (int)argvals.size(), &argvals[0], &inp.out4.value2, };
		if( !val2->evalFunctionCall( ssc ) ){
			assert( !inp.out4.value2 );
			return 0;
		}
		if( !inp.out4.value2 ){ // inp.out4.value2 === ssc.result2
			inp.out4.value2 = new ScpDummyVal( LeftExpr->getOpnToken() );
		}
	}
	assert( inp.out4.value2 );
	return 1;
}
ScpNumericLiteralExpr::ScpNumericLiteralExpr( const ScpToken& tkn_ )
	: ScpIExpr( "ScpNumericLiteralExpr", tkn_ )
{
}
std::string ScpNumericLiteralExpr::strPrint2( const ScpPrnt& inp )const
{
	const ScpToken& tknn = getOpnToken();
	std::string str( tknn.tkn.ptr, tknn.tkn.len );
	std::string z;
	z += *ScpStr("%a%a (numeric-literal)")
			.a( inp.tbs )
			.a( str.c_str() );
	return z;
}
bool ScpNumericLiteralExpr::eval6( const ScpEval& inp )
{
	const ScpToken& tknn = getOpnToken();
	inp.out4.value2 = new ScpNumVal( tknn, tknn.tkn2.c_str(), (int)tknn.tkn2.size() );
	return 1;
}

ScpStrLiteralExpr::ScpStrLiteralExpr( const ScpToken& tkn_ )
	: ScpIExpr( "ScpStrLiteralExpr", tkn_ )
{
}
std::string ScpStrLiteralExpr::strPrint2( const ScpPrnt& inp )const
{
	const ScpToken& tknn = getOpnToken();
	bool bIsQuoted = ( tknn.tkn.len ? !!std::strchr( ScpSp::Qots, *tknn.tkn.ptr ) : 0 );
	std::string str( tknn.tkn.ptr, tknn.tkn.len );
	if( bIsQuoted && !str.empty() && !std::strchr( ScpSp::Qots, *str.rbegin() ) ){
		bIsQuoted = 0;
	}
	std::string z;
	z += *ScpStr("%a""%a%a%a (str-literal)")
			.a( inp.tbs )
			.a( bIsQuoted ? "" : "\x22" ) // 0x22 = dbl quote.
			.a( str.c_str() )
			.a( bIsQuoted ? "" : "\x22" );
	return z;
}
std::string ScpStrLiteralExpr::pseudoevalQuotedStr( const char* inp, int len )
{
	std::string str; //bool bEscd = 0;
	if( len >= 2 && std::strchr( ScpSp::Qots, inp[0] ) ){
		char qmode = inp[0];
		if( inp[len-1] == qmode ){
			inp++;
			len -= 2;
		}
	}
	// parse for: \r \n \t \b \\ \xHH, \uHHHH, etc.
	// SingleEscapeCharacter :: one of ' " \ b f n r t v
	// \0 \1 etc.
	// Back Space = 0x08 = \b //Vertical Tab = 0x0B = \v //Form Feed = 0x0C = \f
	char chr, chr2, *endd;
	for( int i=0; i < len; i++ ){
		chr = inp[i];
		if( chr == '\\' ){
			if( i+1 < len ){
				i++;
				chr2 = inp[i];
				if( chr2 >= '0' && chr2 <= '9' ){
					str += (chr2 - '0');
				}else if( chr2 == 'r' ){
					str += "\r";
				}else if( chr2 == 'n' ){
					str += "\n";
				}else if( chr2 == 't' ){
					str += "\t";
				}else if( chr2 == 'b' ){
					str += "\x08";
				}else if( chr2 == 'v' ){
					str += "\x0B";
				}else if( chr2 == 'f' ){
					str += "\x0C";
				}else if( chr2 == 'x' ){
					if( i+2 < len && isxdigit( inp[i+1] ) && isxdigit( inp[i+2] ) ){
						char xdigits[] = { inp[i+1], inp[i+2], 0, };
						int val = (int)std::strtoul( xdigits, &endd, 16 );
						str += (char)val;
						i += 2;
					}else{
						str += chr2;
					}
				//}else if( chr2 == 'u' ){
				//	assert(!"unicode esc (\\uHHHH) is WIP.");
				//	// possible TODO: convert to UTF-8 sequence.
				}else{
					// else: 0x5C 0x27 0x22, and others. if others, it is
					// a malformed string literal, we dont return any warning.
					str += chr2;
				}
			}else
				str += chr;
		}else
			str += chr;
	}
	return str;
}
bool ScpStrLiteralExpr::eval6( const ScpEval& inp )
{
	const ScpToken& tknn = getOpnToken();
	std::string str = pseudoevalQuotedStr( tknn.tkn.ptr, tknn.tkn.len );
	inp.out4.value2 = new ScpStrVal( tknn, str.c_str(), static_cast<int>(str.size()) );
	return 1;
}
ScpVarStatement::ScpVarStatement( const ScpToken& opn2, const ScpToken& close2 )
	: ScpExprListExpr( opn2, close2 )
{
}
bool ScpVarStatement::eval6( const ScpEval& inp )
{
	assert( getExprCount() >= 1 );
	//const char* szVarNme = getExprAt(0)->getOpnToken().tkn2.c_str();
	//printf("szVarNme: [%s]\n", szVarNme );
	ScpValAutoPtr vinitialiser;
	if( getExprCount() >= 2 ){
		if( !getExprAt(1)->eval6( inp ) )
			return 0;
		vinitialiser.setPointer( inp.extractValue(), 0 );
		assert( vinitialiser() );
	}
	//printf("var [%s]:[%s]\n",
	//		videntifier()->stdToString().c_str(),
	//		( vinitialiser ? vinitialiser->stdToString().c_str() : "<null>" ) );
	ScpPutScopeVar sva( getExprAt(0)->getOpnToken(), vinitialiser(), inp.out4.err4, 0, 1, 1 );
	if( !inp.scope2->putScopeVariable( sva ) )
		return 0;
	inp.out4.value2 = new ScpDummyVal( getOpnToken() );
	return 1;
}
ScpObjLiteralExpr::ScpObjLiteralExpr( const ScpToken& opn2, const ScpToken& close2 )
	: ScpExprListExpr( opn2, close2 )
{
}
bool ScpObjLiteralExpr::eval6( const ScpEval& inp )
{
	const ScpToken& tknn = getOpnToken();
	ScpExprListExpr* exprAcolonB; ScpIExpr* exprLPropName, *exprRAsgmnt;
	//assert( inp.lvalRef );//TMP.
	//assert( inp.out4.lvalRef2 );//TMP.
	ScpObjLiteralVal* varlist = new ScpObjLiteralVal( tknn ); //SCP_E2_ObjectLiteral
	ScpValAutoPtr varlist2( varlist, 0 );
	for( int i=0; i < getExprCount(); i++ ){
		exprAcolonB = dynamic_cast<ScpExprListExpr*>( getExprAt(i) );
		assert( exprAcolonB );
		assert( exprAcolonB->getExprCount() == 2 );
		exprLPropName = exprAcolonB->getExprAt(0); //lhs-expression.
		exprRAsgmnt   = exprAcolonB->getExprAt(1); //rhs-expression.
		assert( exprLPropName && exprRAsgmnt );
		if( !exprLPropName->eval6( inp ) )
			return 0;
		ScpAutoPtr<ScpValue> lhsval( inp.extractValue() );
		assert( lhsval() );
		if( !exprRAsgmnt->eval6( inp ) )
			return 0;
		//ScpAutoPtr<ScpValue> rhsval( inp.extractValue() );
		ScpValue* rhsval = inp.extractValue();
		assert( rhsval );
		if( dynamic_cast<ScpObjLiteralExpr*>(exprRAsgmnt) ){
			assert(!"WIP.");
		}
		varlist->addVal( rhsval, 1, lhsval()->stdToString().c_str() );
	}
	//inp.out4.value2 = new ScpDummyVal( tknn );
	varlist2()->grabVal();
	inp.out4.value2 = varlist2();
	return 1;
}
ScpCtrlFlowStmt::ScpCtrlFlowStmt( int eCtrlFlType_, const ScpToken& tkOpn )
	: ScpIExpr("ScpCtrlFlowStmt",tkOpn)
	, CtrlFlType(eCtrlFlType_)
{
}
std::string ScpCtrlFlowStmt::strPrint2( const ScpPrnt& inp )const
{
	std::string z;
	z += *ScpStr("%a""'%a' (ctrl-flow-statement(%a))")
			.a( inp.tbs )
			.a( getOpnToken().tkn2.c_str() )
			.a( CtrlFlType );
	return z;
}
bool ScpCtrlFlowStmt::eval6( const ScpEval& inp )
{
	if( CtrlFlType == SCP_ECF_EmptyTrue ){  //getCtrlFlowTypeIfAny()
		const ScpToken& tknn = getOpnToken();
		inp.out4.value2 = new ScpIntrnlBoolVal( 1, tknn ); //ScpNumVal
		return 1;
	}
	assert(!"ScpCtrlFlowStmt::eval6() Meant never to be called [3Obuhdok].");
	return 0;
}
ScpFIterationStatement::
ScpFIterationStatement( ScpExprListExpr* innerExprX3, ScpIExpr* blockExpr,
			const ScpToken& opn2, const ScpToken& close2, int flags2 )
	: ScpIExpr( "For-Statement-Expr-__", opn2  ) //innerExprX3->getOpnToken()
	, InnerExprX3(innerExprX3), BlockExpr(blockExpr), ExprElse(0)
	, Flags2(flags2)
{
}
std::string ScpFIterationStatement::strPrint2( const ScpPrnt& inp )const
{
	std::string z;
	ScpExprListExpr dmy0( getOpnToken(), getOpnToken() );
	ScpPrnt in2( inp );
	in2.addTabs(1);
	z += *ScpStr("%a""For-Statement-Expr: '%a' X3:[\n%a\n"
				"%a] '%a' BLK:[\n%a\n"
				"%a] '%a' ELSE:[\n%a\n"
				"%a]")
			.a( inp.tbs )
			.a( getOpnToken().tkn2.c_str() )
			.a( InnerExprX3->strPrint2( in2 ) )
			.a( inp.tbs )
			.a( getOpnToken().tkn2.c_str() )
			.a( BlockExpr->strPrint2( in2 ) )
			.a( inp.tbs )
			.a( getOpnToken().tkn2.c_str() )
			.a( ( ExprElse ? ExprElse : &dmy0)->strPrint2( in2 ) )
			.a( inp.tbs );
	return z;
}
ScpFIterationStatement::~ScpFIterationStatement()
{
	delete BlockExpr;
	delete InnerExprX3;
	if(ExprElse){
		delete ExprElse;
	}
	BlockExpr = 0;
	InnerExprX3 = 0;
	ExprElse = 0;
}
bool ScpFIterationStatement::eval6( const ScpEval& inp )
{
	assert( InnerExprX3->getExprCount() >= 2 );
	// evaluate 1st pre-semicolon expression.
	if( !InnerExprX3->getExprAt( 0 )->eval6( inp ) )
		return 0;
	inp.clear5();
	bool bExpr2Failed = 0;
	int nCntIter = 1;
	for(;; nCntIter++ ){ // for each evaluation of 2nd pre-semicolon expression.
		/// \todo Timed check for infinite loop lock.
		///       The FOR-iteration statement [77clz1U7Y7Nx].
		if( !InnerExprX3->getExprAt( 1 )->eval6( inp ) )
			return 0;
		assert( inp.out4.value2 );
		const bool bE1True = static_cast<int>( inp.out4.value2->stdToDouble() );
		inp.clear5();
		if( !bE1True ){
			bExpr2Failed = 1;
			break;
		}
		// evaluate block|body expression.
		if( !BlockExpr->eval6( inp ) )
			return 0;
		assert( inp.out4.value2 );
		if( Flags2 & SCP_E4_IfStatement && inp.out4.value2->isCtrlFlowValue() )
			return 1;
		const int eCtrlFlowTy = inp.out4.value2->getValueType();
		inp.clear5();
		if( eCtrlFlowTy == SCP_E2_CtrlFlowBreak ){
			break;
		}else if( eCtrlFlowTy == SCP_E2_CtrlFlowContinue ){
			continue;
		}
		if( Flags2 & SCP_E4_IfStatement )
			break;
		// evaluate 3rd expression.
		if( !InnerExprX3->getExprAt( 2 )->eval6( inp ) )
			return 0;
		inp.clear5();
	}
	if( bExpr2Failed && ExprElse ){
		assert( nCntIter == 1 );
		if( !ExprElse->eval6( inp ) )
			return 0;
		inp.clear5();
	}
	inp.out4.value2 = new ScpDummyVal( getOpnToken() );
	return 1;
}
void ScpFIterationStatement::setTheElseExpr( ScpIExpr* exprElse )
{
	assert( !ExprElse );
	ExprElse = exprElse;
}
ScpFIterationBody::
ScpFIterationBody( const ScpToken& opn2, const ScpToken& close2 )
	: ScpExprListExpr(opn2,close2)
{
}
bool ScpFIterationBody::eval6( const ScpEval& inp )
{
	for( int iii = 0; iii < getExprCount(); iii++ ){
		ScpIExpr* expr = getExprAt(iii);
		assert(expr);
		ScpCtrlFlowStmt* cfs = dynamic_cast<ScpCtrlFlowStmt*>( expr );
		const int eCfTy2 = ( cfs ? cfs->getCtrlFlowTypeIfAny() : SCP_ECF_None );
		if( eCfTy2 == SCP_ECF_Break ){
			inp.out4.value2 = new ScpDummyVal( expr->getOpnToken(), SCP_E2_CtrlFlowBreak );
			return 1;
		}else if( eCfTy2 == SCP_ECF_Continue ){
			inp.out4.value2 = new ScpDummyVal( expr->getOpnToken(), SCP_E2_CtrlFlowContinue );
			return 1;
		}
		if( !expr->eval6( inp ) )
			return 0;//;inp.extractValue();
		assert( inp.out4.value2 );
		if( inp.out4.value2->isCtrlFlowValue() )
			return 1;
		inp.clear5();
	}
	inp.out4.value2 = new ScpDummyVal( getOpnToken() );
	return 1;
}
ScpBuiltinFuncIdentifierExpr::ScpBuiltinFuncIdentifierExpr( const ScpToken& tkn )
	: ScpIdentifierExpr( tkn )
{
}
bool ScpBuiltinFuncIdentifierExpr::eval6( const ScpEval& inp )
{
	inp.out4.value2 = new ScpDummyVal( getOpnToken(), SCP_E2_BuiltinFunc );
	//evalFunctionCall
	return 1;
}

bool ScpAxBExpr::
evalCompoundOp( const ScpEval& inp, ScpValue* lval2, ScpValue* rval2, const char* op2 )const
{
	ScpSpeOper sop3 = { inp, rval2, &inp.out4.value2, };
	if( !std::strcmp( ScpSp::OpCmpndAdd, op2 ) ){
		if( !lval2->evalOperatorAdd( sop3 ) )
			return 0;
	}else if( !std::strcmp( ScpSp::OpCmpndSub, op2 ) ){
		if( !lval2->evalOperatorSub( sop3 ) )
			return 0;
	}else if( !std::strcmp( ScpSp::OpCmpndMul, op2 ) ){
		if( !lval2->evalOperatorMul( sop3 ) )
			return 0;
	}else if( !std::strcmp( ScpSp::OpCmpndDiv, op2 ) ){
		if( !lval2->evalOperatorDiv( sop3 ) )
			return 0;
	}else if( !std::strcmp( ScpSp::OpCmpndPercent, op2 ) ){
		if( !lval2->evalOperatorPercent( sop3 ) )
			return 0;
	}else{
		assert(!"Unknown operator.");
	}
	assert( inp.out4.value2 );
	ScpValue* val3 = inp.extractValue();
	ScpSpeOper sop4 = { inp, val3, &inp.out4.value2, };
	if( !lval2->evalOperatorAssign( sop4 ) )
		return 0;
	val3->dropVal();
	if( !inp.out4.value2 )
		inp.out4.value2 = lval2;//*/
	return 1;
}




