#include "scipp_builtins.h"
#include <assert.h>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include "../inc/scipp/scipp_script.h"
#include "scipp_expr.h"
#include "scipp_value.h"

void ScpBuiltins::
genericBadArgcError( int nExpected, int nGot, const ScpToken& tknn, const ScpEval& outp )
{
	outp.errClear2( ScpErr( tknn.tkn, SCP_EE_BadBuiltinFuncCall,
		(*ScpStr(
			"Wrong arg count for builtin function '%a', expected %a, got %a.")
				.a( tknn.tkn2.c_str() ).a( nExpected ).a( nGot )
			).c_str() ) );
}
/// Generic error on bad arg type.
/// \param nArgIdx - cakk argument index, 0-based.
void ScpBuiltins::
genericBadArgTypeError( int nArgIdx, const char* szExpectedTy, const ScpToken& tknn, const ScpEval& outp )
{
	outp.errClear2( ScpErr( tknn.tkn, SCP_EE_UnkBuiltinFuncName,
		(*ScpStr("Bad type for argument #%a, in function: '%a', expected: '%a'")
			.a( nArgIdx+1 )
			.a( tknn.tkn2.c_str() )
			.a( szExpectedTy ) ).c_str() ) );
}
bool ScpBuiltins::evalBuiltinCall( const ScpEbcSpeCall& inp )
{
	//inp.sevc2.sev;     //ScpEval
	//inp.sevc2.argc2;   //int
	//inp.sevc2.argv2;   //const ScpValue*const*
	//inp.sevc2.result2; //ScpValue**
	//inp.szBltnName;    //const char*
	const int argc3 = inp.sevc2.argc2;
	const ScpValue* const arg0 = ( argc3 >= 1 ? inp.sevc2.argv2[0] : 0 );
	const ScpValue* const arg1 = ( argc3 >= 2 ? inp.sevc2.argv2[1] : 0 );
	const ScpValue* const arg2 = ( argc3 >= 3 ? inp.sevc2.argv2[2] : 0 );
	const bool bEq = !std::strcmp("sc_eq",inp.szBltnName);
	const bool bLt = !std::strcmp("sc_lt",inp.szBltnName);
	const bool bLe = !std::strcmp("sc_le",inp.szBltnName);
	if( bEq || bLt || bLe ){
		//sc_lt
		if( argc3 != 2 ){
			genericBadArgcError( 2, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		{
			const ScpNumVal* nv0 = dynamic_cast<const ScpNumVal*>( arg0 );
			const ScpNumVal* nv1 = dynamic_cast<const ScpNumVal*>( arg1 );
			if( nv0 && nv1 ){
				bool bTrue = (
					bEq ? nv0->stdToDouble() == nv1->stdToDouble() : (
					bLt ? nv0->stdToDouble() < nv1->stdToDouble() : (
					bLe ? nv0->stdToDouble() <= nv1->stdToDouble() : 0 ) ) );
				*inp.sevc2.result2 = new ScpIntrnlBoolVal( bTrue, inp.tkn3 );
				return 1;
			}
		}{
			const ScpStrVal* sv0 = dynamic_cast<const ScpStrVal*>( arg0 );
			const ScpStrVal* sv1 = dynamic_cast<const ScpStrVal*>( arg1 );
			if( sv0 && sv1 ){
				const std::string& sr0 = sv0->getStringData();
				const std::string& sr1 = sv1->getStringData();
				//bool bTrue = sr0 == sr1;
				bool bTrue = (
					bEq ? sr0 == sr1 : (
					bLt ? ( std::strcmp( sr0.c_str(), sr1.c_str() ) < 0 ) : (
					bLe ? ( std::strcmp( sr0.c_str(), sr1.c_str() ) <= 0 ) : 0 ) ) );
				*inp.sevc2.result2 = new ScpIntrnlBoolVal( bTrue, inp.tkn3 );
				return 1;
			}
		}
		inp.sevc2.sev.errClear2( ScpErr( inp.tkn3.tkn, SCP_EE_BadBuiltinFuncCall,
			(*ScpStr("Unsupported types for comparision durning a call to '%a'")
					.a( inp.tkn3.tkn2.c_str() ) ).c_str() ) );
		return 0;
	}else if( !std::strcmp("sc_not",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		bool bRslt = !( arg0->stdToDouble() );
		*inp.sevc2.result2 = new ScpIntrnlBoolVal( bRslt, inp.tkn3 );
		return 1;
	}else if( !std::strcmp("sc_len",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const ScpStrVal* sv0 = dynamic_cast<const ScpStrVal*>( arg0 );
		int nLenOu = 1;
		if( sv0 ){
			nLenOu = static_cast<int>( sv0->getStringData().size() );
		}else{
			// ScpValListVal == ScpObjLiteralVal
			const ScpValListVal* lsv0 = dynamic_cast<const ScpValListVal*>( arg0 );
			nLenOu = ( lsv0 ? lsv0->getValCount() : nLenOu );
		}
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, nLenOu );
		return 1;

	}else if( !std::strcmp("sc_substr",inp.szBltnName) ){
		// PHP: substr( string $string , int $start [, int $length ] )
		if( argc3 != 3 ){
			genericBadArgcError( 3, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const ScpStrVal* sv0 = dynamic_cast<const ScpStrVal*>( arg0 );
		if( !sv0 ){
			genericBadArgTypeError( 0, "string", inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		std::string str2;
		const std::string& sstr = sv0->getStringData();
		int nMaxLen = static_cast<int>( sstr.size() );
		int nStart  = static_cast<int>( arg1->stdToDouble() );
		int nLength = static_cast<int>( arg2->stdToDouble() );
		if( nStart < 0 ){
			nStart = std::abs(nStart);
			nStart = std::max( nMaxLen - nStart, 0 );
		}
		if( nStart < nMaxLen )
			str2 = sstr.substr( nStart, ( nLength >= 0 ? nLength : std::string::npos ) );
		*inp.sevc2.result2 = new ScpStrVal( inp.tkn3, str2.c_str(), static_cast<int>( str2.size() ) );
		return 1;
	}else if( !std::strcmp("sc_print",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const ScpStrVal* sv0 = dynamic_cast<const ScpStrVal*>( arg0 );
		if( !sv0 ){
			genericBadArgTypeError( 0, "string", inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const std::string& sstr = sv0->getStringData();
		std::printf("%s", sstr.c_str() );
		*inp.sevc2.result2 = new ScpIntrnlBoolVal( false, inp.tkn3 );
		return 1;
	}else if( !std::strcmp("sc_strval",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		std::string str = arg0->stdToString();
		*inp.sevc2.result2 = new ScpStrVal( inp.tkn3, str.c_str(), str.size() );
		return 1;
	}else if( !std::strcmp("sc_intval",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const int nVal = static_cast<int>( arg0->stdToDouble() );
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, nVal );
		return 1;

	}else if( !std::strcmp("sc_floatval",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3,
					arg0->stdToDouble() );
		return 1;
	}else if( !std::strcmp("sc_flush",inp.szBltnName) ){
		if( argc3 != 0 ){
			genericBadArgcError( 0, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		std::fflush( stdout );
		*inp.sevc2.result2 = new ScpIntrnlBoolVal( false, inp.tkn3 );
		return 1;
	}else if( !std::strcmp("sc_min",inp.szBltnName) || !std::strcmp("sc_max",inp.szBltnName) ){
		const bool bMin = !std::strcmp("sc_min",inp.szBltnName);
		if( argc3 < 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double rs2 = arg0->stdToDouble();
		for( int i=1; i<argc3; i++ ){
			double v = inp.sevc2.argv2[i]->stdToDouble();
			rs2 = ( bMin ? std::min( rs2, v ) : std::max( rs2, v ) );
		}
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, rs2 );
		return 1;
	}else if( !std::strcmp("sc_abs",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double rs2 = arg0->stdToDouble();
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, std::abs( rs2 ) );
		return 1;
	}else if( !std::strcmp("sc_sqrt",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double rs2 = arg0->stdToDouble();
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, std::sqrt( rs2 ) );
		return 1;
	}else if( !std::strcmp("sc_pow",inp.szBltnName) ){
		if( argc3 != 2 ){
			genericBadArgcError( 2, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double v = arg0->stdToDouble();
		double exp2 = arg1->stdToDouble();
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, std::pow( v, exp2 ) );
		return 1;
	}else if( !std::strcmp("sc_modf",inp.szBltnName) ){
		if( argc3 != 1 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double dmy0, v = arg0->stdToDouble();
		double fFractional = std::modf( v, &dmy0 );
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, fFractional );
		return 1;
	}else if( !std::strcmp("sc_fmod",inp.szBltnName) ){
		if( argc3 != 2 ){
			genericBadArgcError( 2, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		double x = arg0->stdToDouble();
		double y = arg1->stdToDouble();
		double rs2 = std::fmod( x, y );
		*inp.sevc2.result2 = new ScpNumVal( inp.tkn3, rs2 );
		return 1;
	}else if( !std::strcmp("sc_divmod",inp.szBltnName) ){
		if( argc3 != 2 ){
			genericBadArgcError( 2, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		const int64_t x = static_cast<int64_t>( arg0->stdToDouble() );
		const int64_t y = static_cast<int64_t>( arg1->stdToDouble() );
		const int64_t fQuotient = x / y;
		const int64_t fRemainder = x % y;
		ScpValListVal* vlv = new ScpObjLiteralVal( inp.tkn3 );
		vlv->addVal( new ScpNumVal( inp.tkn3, fQuotient ), 1, "q" );
		vlv->addVal( new ScpNumVal( inp.tkn3, fRemainder ), 1, "r" );
		*inp.sevc2.result2 = vlv;
		return 1;
	}else if( !std::strcmp("sc_list",inp.szBltnName) ){
		// sc_list() provides tuple like functionaluty.
		// last argument must be an array that that gets its values
		// re-assigned  into new identifiers using string names from
		// args 0 to n-2.empty strings can be used to skip
		// particular array element.
		if( argc3 < 2 ){
			genericBadArgcError( 1, argc3, inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		ScpObjLiteralVal* olv0 = dynamic_cast<ScpObjLiteralVal*>( inp.sevc2.argv2[argc3-1] );
		if( !olv0 ){
			genericBadArgTypeError( argc3-1, "object_literal", inp.tkn3, inp.sevc2.sev );
			return 0;
		}
		if( olv0->getPropertyCount() < (argc3-1) ){
			inp.sevc2.sev.errClear2( ScpErr( inp.tkn3.tkn, SCP_EE_UnkBuiltinFuncName,
				(*ScpStr("Not enough values to unpack using '%a', requested: %a, have: %a.")
					.a( inp.tkn3.tkn2.c_str() )
					.a( (argc3-1) )
					.a( olv0->getPropertyCount() )
					 ).c_str() ) );
			return 0;
		}
		for( int i=0; i < (argc3-1); i++ ){
			const ScpValue* argx = inp.sevc2.argv2[i];
			const ScpStrVal* sr0 = dynamic_cast<const ScpStrVal*>( argx );
			if( !sr0 ){
				genericBadArgTypeError( i, "string", inp.tkn3, inp.sevc2.sev );
				return 0;
			}
			ScpValue* prp = olv0->getPropertyAt( i, 0 );
			assert(prp);
			const std::string& sstr = sr0->getStringData();
			if( !sstr.empty() ){
				ScpPutScopeVar spsv( inp.tkn3,
						prp, inp.sevc2.sev.out4.err4,
						sstr.c_str(), 1, 1
				);
				if( !inp.sevc2.sev.scope2->putScopeVariable( spsv ) ){
					return 0;
				}
			}
		}
		*inp.sevc2.result2 = new ScpIntrnlBoolVal( false, inp.tkn3 );
		return 1;
	}
	inp.sevc2.sev.errClear2( ScpErr( inp.tkn3.tkn, SCP_EE_UnkBuiltinFuncName,
			(*ScpStr("Unknown builtin function name: '%a'.")
					.a(inp.tkn3.tkn2.c_str())).c_str() ) );
	return 0;
}


