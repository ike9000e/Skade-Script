#ifndef _SCIPP_SCRIPT_H_
#define _SCIPP_SCRIPT_H_
#include <string>

struct ScpErr; class ScpHostObject; class ScpHostOp; class ScpScript;

// Both ScpCreateScript() functions implemented in  "scipp_script2.cpp".
ScpScript* ScpCreateScript( const char* script_text, int len, bool bCreateInternalCopy );
ScpScript* ScpCreateScript( const std::string& script_text );

/**
	Script parser, abstract calss.
	Docs are work in progress.
	Please see derived ScpScript2 class for documentation details on each
	member function.
	In user code, use ScpCreateScript() function to create instance of this class.
*/
class ScpScript {
public:
	virtual             ~ScpScript() {}
	/// \copydoc ScpScript2::parseAndEval()
	virtual bool        parseAndEval() = 0;
	/// \copydoc ScpScript2::parse2()
	virtual bool        parse2() = 0;
	/// \copydoc ScpScript2::parse3()
	virtual bool        parse3( int flags_, ScpErr* err ) = 0;
	/// \copydoc ScpScript2::eval2()
	virtual bool        eval2() = 0;
	/// \copydoc ScpScript2::eval3()
	virtual bool        eval3( int flags_, ScpErr* err ) = 0;
	/// \copydoc ScpScript2::showMeTheError2()
	virtual void        showMeTheError2()const = 0;
	/// \copydoc ScpScript2::showMeTheError3()
	virtual std::string showMeTheError3( bool bShortOutput )const = 0;
	/// \copydoc ScpScript2::addHostObject()
	virtual void        addHostObject( const char* objectname, ScpHostObject* hobject, bool bOwnAndDel ) = 0;
	/// \copydoc ScpScript2::addHostOperator()
	virtual void        addHostOperator( ScpHostOp* hoperator, bool bOwnAndDel ) = 0;
	/// \copydoc ScpScript2::clear2()
	virtual void        clear2() = 0;
	/// \copydoc ScpScript2::clear3()
	virtual void        clear3( int flags_ ) = 0;
	/// \copydoc ScpScript2::setCondDef()
	virtual void        setCondDef( const char* dname, bool val ) = 0;
	/// \copydoc ScpScript2::setOptions()
	virtual void        setOptions( int flags_ ) = 0;
};

/// Flags for ScpScript::eval3().
enum{
	/**
		Can be set at the evaluation step to perform required parsing automatically.
		Normally, user calls ScpScript::parse2() then ScpScript::eval2(),
		both functions manually.
		Using this flag enables parsing and evaluating to be done in one step,
		durning ScpScript::eval2() call.
		\sa \ref pgParseEval
	*/
	SCP_AF_AutoParse = 0x1,
};
/// Flags for ScpScript::clear3().
enum{
	SCP_CF_ClearParser = 0x2,
	SCP_CF_ClearStack = 0x4,
	SCP_CF_ClearCondDefs = 0x8,
	SCP_CF_ClearAll = SCP_CF_ClearParser|SCP_CF_ClearStack|SCP_CF_ClearCondDefs,
};
/// Flags for ScpScript::setOptions().
enum{
	/// Shows tokens by printing them to the console STDOUT durning parsing.
	SCP_SF_ShowTokens = 0x1,
	/// Similar to \ref SCP_SF_ShowTokens.
	SCP_SF_ShowExpressions = 0x2,
	/// Similar to \ref SCP_SF_ShowTokens.
	SCP_SF_ShowCondDefs = 0x4,
	/// If set, error line is not trimmed if too long.
	/// If not set, when showing the error with
	/// \ref ScpScript::showMeTheError3() ".showMeTheError3()",
	/// the original source code line the error happened at,
	/// is trimmed down from the right, in case if it ends up being
	/// longer than some predefined length.
	SCP_SF_NoErrLineRTrim = 0x8,
	/// If set, disables pseudo preprocessor.
	SCP_SF_DisablePreproc = 0x10,
};

/// Flags for error type.
/// \ref ScpErr::tpe3.
enum {
	SCP_EE_Unknown = 0,
	// on tokenizer.
	SCP_EE_UnkToken = 1, SCP_EE_CommentNoClose,
	// pseudo preprocessor, still countet as tokenizer.
	SCP_EE_NoMatchingEndif = 30, SCP_EE_UnxpctdEndif, SCP_EE_UntrmtdIfdef, SCP_EE_IfdefEof,
	SCP_EE_BadIfdefCond,
	// on parser.
	SCP_EE_EofOnParse = 100, SCP_EE_UnexpTk2, SCP_EE_UnexpTk3, SCP_EE_EofNoBrace,
	SCP_EE_UnkExpr, SCP_EE_NoSemicln, SCP_EE_UnparsableExpr, SCP_EE_EofOnAxB,
	SCP_EE_EofOnAxB2, SCP_EE_NotOperOnAxB, SCP_EE_NotOperOnAsgnmt, SCP_EE_NotOperOnAsgnmt2,
	SCP_EE_AxBExprParseFailed, SCP_EE_NoGroupCloseHere, SCP_EE_NoGroupCloseHere2, SCP_EE_GroupingNoInner,
	SCP_EE_ArgListNoAsgmntExpr, SCP_EE_NoCommaOrPClHere, SCP_EE_NoCommaOrPClHere2,
	// on evaluator.
	SCP_EE_UserEvalNull = 200, SCP_EE_UndefVar2, SCP_EE_UnknownOp, SCP_EE_UnkExpr3,
	SCP_EE_NoSuchHostObject, SCP_EE_NoSuchHostObject2, SCP_EE_NoSuchHostOper, SCP_EE_NoSuchHostObject3,
	SCP_EE_UnkErrOnUsrCall, SCP_EE_UsrCallNotImpl,
};



/**
	Parameters on host object function call.
	In particuar, parameters for ScpHostObject::evaluateFunctionCall().
	This is the structute that, on functiona call, passes
	function arguments from the script into the C++.
*/
struct ScpHoc {
	/// Number of arguments in the 'argvv' member.
	int                   argvc;
	/// The arguments. Pointers are likely to be upcasted (dynamic_cast)
	/// into expected user types.
	ScpHostObject*const*  argvv;
	/// Used on error. Tells which argument triggers the error or if error
	/// is caused by the object call is performed on.
	/// Value 0 indicates error caused by the host object itself.
	/// Value >= 1 instead, tells that error is caused by one of the arguments
	/// ('argvv').
	int*                  iErrIs;
	/// Error code, defaults to \ref SCP_EE_UnkErrOnUsrCall.
	int*                  eErr;
	/// Return value, if any, as result of the evaluation.
	/// Defaults to 0, which indicates no return value,
	/// aka. 'void' return value.
	/// Currently, should be set to 0. Other functonality requires
	/// more testing.
	ScpHostObject**       retval;
};



/// Class that must be base of all objects that can be imported to the
/// scripts.
/// \sa \ref pgHostObjects
class ScpHostObject { public:
	virtual      ~ScpHostObject() {}
	virtual bool evaluateFunctionCall( const ScpHoc& inp );
};
struct ScpHof{
	ScpHostObject*  lval;
	const char*     oper;
	ScpHostObject*  rval;
	/// Return value of the operation must be the pointer saved here.
	ScpHostObject** retval;
	/// On error, number that tells which part of the input is the problem.
	/// 0: 'lval', 1: 'rval' or -1: operator.
	int*            iErrIs;
	/// Error code, eg: \ref SCP_EE_Unknown.
	int*            eErr;
};

/**
	Interface for building operators that get imported from the
	host environment (C++ end) into the scripts.
*/
class ScpHostOp{ public:
	virtual             ~ScpHostOp() {}
	virtual bool        callHostOperatorFnc( const ScpHof& inp ) = 0;
	virtual const char* getOpName()const = 0;
};


/**
    Generic Template class for implementing operators
	like assignment or addition. For importing objects
	from the host environment (C++ end) into the scripts.
	Requirements on a class that is passed as templeate parameter 'TVar':
	- must be derived from \ref ScpHostObject.
	- must provide appropriate, one or more, C++ operator functions,
	  that, in turn, classes derived from this (ScpHostTOperator) use.

    There already exist, less generic, handfull list of template classes for operators:
	"*", "+" and "=", respectivelly: ScpPlusOperator,
	ScpMultiplicativeOperator or ScpAsssignmentOperator.
    If they can't provide sufficient features, this class can be used to
    reimplement them.
    \sa \ref pgHostObjects
*/
template<class TVar>
class ScpHostTOperator : public ScpHostOp {
	struct SOper;
public:
	/// Main method of the host operator class.
	/// After performing it's operation, and either creating new object, or
	/// modyfying one of operands, result must be returned as a member of the
	/// input structire.
	/// \return Returns true on success.
	virtual ScpHostObject* evaluateAxB( TVar& A, TVar& B ) = 0;
	/// Returns just operator as c-string (aka null-terminated string).
	/// Eg. "+" or "=".
	virtual const char* getOpName()const = 0;
	/// Called from the library, default implementation should be functional enough.
	virtual bool callHostOperatorFnc( const ScpHof& inp )
	{
		TVar* A = dynamic_cast<TVar*>( inp.lval );
		TVar* B = dynamic_cast<TVar*>( inp.rval );
		if( !A || !B ){
			*inp.iErrIs = ( !A? 0 : 1 );
			*inp.eErr = SCP_EE_NoSuchHostObject;
			;
			;
			return 0;
		}
		*inp.retval = evaluateAxB( *A, *B );
		return 1;
	}
};
/// Multiplicative operator ("*").
/// \sa \ref pgHostObjects
template<class TVar>
class ScpMultiplicativeOperator : public ScpHostTOperator<TVar>
{
public:
	virtual const char* getOpName()const {return "*";}
	virtual ScpHostObject* evaluateAxB( TVar& A, TVar& B ){
		TVar* C = new TVar;
		*C = A * B;
		return C;
	}
};
/// Plus (or additive) operator ("+").
/// \sa \ref pgHostObjects
template<class TVar>
class ScpPlusOperator : public ScpHostTOperator<TVar> { public:
	virtual const char* getOpName()const {return "+";}
	virtual ScpHostObject* evaluateAxB( TVar& A, TVar& B ){
		TVar* C = new TVar;
		*C = A + B;
		return C;
	}
};
/// Assignment operator, the '='.
/// Note that there is a difference in comparision versus plus or multiplicative
/// operators. Instead of creating a new object instance, one of the operand objects,
/// normally left, must be modified and pointer to it returned.
/// \sa \ref pgHostObjects
template<class TVar>
class ScpAsssignmentOperator : public ScpHostTOperator<TVar> { public:
	virtual const char* getOpName()const {return "=";}
	virtual ScpHostObject* evaluateAxB( TVar& A, TVar& B ){
		A = B;
		return &A;
	}
};

#endif //_SCIPP_SCRIPT_H_
